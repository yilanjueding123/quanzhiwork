/*
*********************************************************************************************************
*                                                    MELIS
*                                    the Easy Portable/Player Develop Kits
*                                           Matrix Key Driver Module
*
*                                    (c) Copyright 2006-2010, All winners Co,Ld.
*                                             All Rights Reserved
*
* File    : matrix_key.c
* By      : james deng <csjamesdeng@gmail.com>
* Version : 1.0.0
* Date    : 2011-04-25
* Descript:
* Update  : date              author         ver       notes
*           2011-04-25        james deng     1.0.0     build the file.
*********************************************************************************************************
*/

#include "drv_matrix_key_i.h"
#include "bsp_rk.h"

#if  0
//#define __here__            eLIBs_printf("@L%d(%s)\n", __LINE__, __FILE__);
#define __msg(...)    		(eLIBs_printf("MSG:L%d(%s):", __LINE__, __FILE__),                 \
						     eLIBs_printf(__VA_ARGS__)									        )
#else
#define __msg(...)    	
#endif


#define MENU        0x00000001
#define VOL_ADD     0x00000002
#define VOL_DEC     0x00000004
#define LEFT        0x00000008
#define RIGHT       0x00000010
#define ENTER       0x00000020


#define			NOKEY		0xffff
static u32		PrevKeyValue = NOKEY;
static __hdle	input_y2 = 0;
static ES_FILE  *iic_file;
static __u32 g_pw_off_support = 1;//Ϊ1�����ʹ��PA3�ڼ��ػ�����jtag�ڸ���

static __u32 input_row1 = 0;
static __u32 input_row2 = 0;
static __u32 input_row3 = 0;
static __u32 x2_output = 0;
static __u32 y1_output = 0;
static __u32 first_power_on_cnt = 0;
static __u8  first_poweron_flag = 0;

__u8 adc_key_init_ok = 0;
__u8 key_time_count = 0;
__u8 adc_key_down = 0;
__u8 ex_key_down = 0;
static __u32 pw_off = 0;
__u32  sinle_level_value = 0;
__u32  prev_single_level_value = 0x55;

/* ɨ������ */
static __s32 period;
/* �ػ�ʱ�� */
static __s32 pw_off_time;
/* ���������ӳٵ�ʱ�䣬��Ϊɨ�����ڵı���������û����� */
static __s32 key_down_delay;

static __s32 volatile is_power_off = EPDK_FALSE;
static __krnl_stmr_t *timer = NULL;

static __u8 matrix_key_tid = 0;

//���¶���Ϊ�˽������ϰ����������¿��ܳ��ֵİ���down��up��Ϣ����Ե����
static __u32 g_key_down_tbl[KEY_CNT] = {0};

void Matrixkey_ScanThread();//(void *p_arg)
__u32 adc_key_scan();
/********************************************************************************************************
* Function:    matrix_key_read
* Description: read routine
* Input��
* Output��
* Other��
*********************************************************************************************************/
static __u32 Request_GPIO(const char *ioname, int downup)
{
    __u32			 GPIO;
    __s32            ret;
    user_gpio_set_t  gpio_set[1];

    eLIBs_memset(gpio_set, 0, sizeof(user_gpio_set_t));
    ret = esCFG_GetKeyValue("matrixkey_para", (char *)ioname, (int *)gpio_set, sizeof(user_gpio_set_t) / 4);
    if (!ret)
    {
        GPIO = esPINS_PinGrpReq(gpio_set, 1);
        if (!GPIO)
        {
            __wrn("request %s pin failed\n", ioname);
            return 0;
        }
    }

    else

    {
        __wrn("%s fetch para from script failed\n", ioname);
        return 0;
    }

    if(downup == 2)
    {
        ret = esPINS_SetPinPull(GPIO, PIN_PULL_DOWN, NULL);

        if (ret)
        {
            __wrn("pull %s failed\n", ioname);
            return 0;
        }
    }
    else if(downup == 1)
    {
        ret = esPINS_SetPinPull(GPIO, PIN_PULL_UP, NULL);

        if (ret)
        {
            __wrn("pull %s failed\n", ioname);
            return 0;
        }

    }

    return GPIO;
}

/********************************************************************************************************
* Function:    matrix_key_down
* Description: matrix key down
* Input��
* Output��
* Other��
*********************************************************************************************************/
static void matrix_key_down(__u32 key_value)
{
    __key_msg_t msg;

    msg.key_value = key_value;
    msg.flag = 1;

    //eLIBs_printf("&&&&&&&&&&& KEY DOWN &&&&&&&&&&\n");
    dev_matrix_key_ioctrl(0, DRV_KEY_CMD_PUTKEY, 0, &msg);

    g_key_down_tbl[key_value]++;
}

/********************************************************************************************************
* Function:    matrix_key_up
* Description: matrix key up
* Input��
* Output��
* Other��
*********************************************************************************************************/
static void matrix_key_up(__u32 key_value)
{
    __key_msg_t msg;

    if(g_key_down_tbl[key_value] > 0)
    {
        g_key_down_tbl[key_value]--;
    }
    else
    {
        return ;
    }

    //eLIBs_printf("&&&&&&&&&&& KEY UP &&&&&&&&&&\n");

    msg.key_value = key_value;
    msg.flag = 0;

    dev_matrix_key_ioctrl(0, DRV_KEY_CMD_PUTKEY, 0, &msg);
}

/********************************************************************************************************
* Function:    matrix_key_read
* Description: read routine
* Input��
* Output��
* Other��
*********************************************************************************************************/
static __u32 matrix_key_read()
{
    __s32 d1 = 0, d2 = 0, d3 = 0;
    __u32 input_row2 = 0, input_row3 = 0;
    __u32 output_col1 = 0, output_col2 = 0;
    if(1 == g_pw_off_support)
    {
        d1 = esPINS_ReadPinData(pw_off, 0);
        if (d1)
        {
            return KPAD_POWER;
        }
    }
    input_row2 = Request_GPIO((const char *)"input_row2", 2);
    if(input_row2 == 0)
    {
        return 0;
    }
    input_row3 = Request_GPIO((const char *)"input_row3", 2);
    if(input_row3 == 0)
    {
        esPINS_PinGrpRel(input_row2, 0);
        return 0;
    }
    d1 = esPINS_ReadPinData(input_row1, 0);
    d2 = esPINS_ReadPinData(input_row2, 0);
    d3 = esPINS_ReadPinData(input_row3, 0);
    if (!(d1 | d2 | d3))
    {
        esPINS_PinGrpRel(input_row3, 0);
        input_row3 = 0;
        output_col2 = Request_GPIO((const char *)"output_col2", 1);
        if(output_col2 == 0)
        {
            esPINS_PinGrpRel(input_row2, 0);
            return 0;
        }
        esPINS_WritePinData(output_col2, 1, NULL);
        d1 = esPINS_ReadPinData(input_row1, 0) ? LEFT : 0;
        d2 = esPINS_ReadPinData(input_row2, 0) ? RIGHT : 0;
        if (!(d1 | d2))
        {
            esPINS_PinGrpRel(input_row2, 0);
            input_row2 = 0;
            output_col1 = Request_GPIO((const char *)"output_col1", 1);
            if(output_col1 == 0)
            {
                esPINS_PinGrpRel(output_col2, 0);
                return 0;
            }
            esPINS_WritePinData(output_col1, 1, NULL);
            d1 = esPINS_ReadPinData(input_row1, 0) ? MENU : 0;
        }
        else
        {
            d1 = d1 | d2;
        }
    }
    else
    {
        if (d1)
        {
            d1 = esPINS_ReadPinData(input_row1, 0) ? VOL_ADD : 0;
        }
        if (d2)
        {
            d2 = esPINS_ReadPinData(input_row2, 0) ? ENTER : 0;
        }
        if (d3)
        {
            d3 = esPINS_ReadPinData(input_row3, 0) ? VOL_DEC : 0;
        }
        d1 = d1 | d2 | d3;
    }
    switch (d1)
    {
    case LEFT:
        d1 = KPAD_LEFT;
        break;
    case RIGHT:
        d1 = KPAD_RIGHT;
        break;
    case MENU:
        d1 = KPAD_MENU;
        break;
    case ENTER:
        d1 = KPAD_ENTER;
        break;
    case VOL_ADD:
        d1 = KPAD_VOICEUP;
        break;
    case VOL_DEC:
        d1 = KPAD_VOICEDOWN;
        break;
    default:
        d1 = 0;
    }
    if(input_row2)
        esPINS_PinGrpRel(input_row2, 0);
    if(input_row3)
        esPINS_PinGrpRel(input_row3, 0);
    if(output_col1)
        esPINS_PinGrpRel(output_col1, 0);
    if(output_col2)
        esPINS_PinGrpRel(output_col2, 0);
    return d1;
}
static __s32 get_adc_valume(void)
{
#define AD_DATA_NUM 8
    __u32 ret;
    __s32 data[AD_DATA_NUM];
    __s32 data_out[AD_DATA_NUM];
    __s32 average;
    __s32 i;
    __s32 cnt;
    __s32 valid_num;
    cnt = 0;
    while(1)
    {
        ret = RK_QueryIntPending();
        if(ret & RK_DATA_PENDING)
        {
            RK_GetData(data, sizeof(data) / sizeof(data[0]));
            RK_ClearIntPending(ret);
            RK_ClearFifo();
            break;
        }
        if(cnt++ > 2)
        {
            RK_ClearIntPending(ret);
            RK_ClearFifo();
            break;
        }
        esKRNL_TimeDly(1);
    }
    if(!(ret & RK_DATA_PENDING))
    {
        return 0x7ff;//ֱ�ӷ������ֵ��Ĭ��Ϊû�С�
    }
#if 1//C500�������ȱ�C100��1bit�����Գ���2
    {
        for(i = 0 ; i < sizeof(data) / sizeof(data[0]) ; i++)
        {
            data[i] /= 2;
        }
    }
#endif
    {
        valid_num = 0;
        for(i = 0 ; i < sizeof(data) / sizeof(data[0]) ; i++)
        {
            if(data[i] < 0x7ff)
            {
                data[valid_num++]  = data[i];
            }
        }
    }
    if(valid_num <= 0)
    {
        return 0x7ff;
    }
    valid_num = data_filter(data, data_out, valid_num);
    average = 0;
    for(i = 0 ; i < valid_num ; i++)
    {
        average += data_out[i];
    }
    average /= valid_num;
    return average;
}
__s32 data_filter(__s32 *input, __s32  *output , int arr_len)
{
    __s32 tmp, i, j, half, rec, k = 0;
    __s32 *data;
    data = input;
    i = arr_len;
    for(i = 0; i < arr_len - 1; i++)
        for(j = 0; j < arr_len - i - 1; j++)
        {
            if(data[j] > data[j + 1])
            {
                tmp = data[j];
                data[j] = data[j + 1];
                data[j + 1] = tmp;
            }
        }
    half = arr_len / 2;
    for(i = 0; i < arr_len; i++)
    {
        if(data[half] > data[i])
            rec = data[half] - data[i];
        else
            rec = data[i] - data[half];
        if(rec < 30)
        {
            output[k] = data[i];
            k++;
        }
    }
    return k;
}
static __u32 adc_single_scan_X1()
{
    __s32 adc_valume;
    __u32  level = 0;

    adc_valume = get_adc_valume();
    if(adc_valume < 300) //420
        level = KPAD_SINGLE0;
    else if(adc_valume < 510)
        level = KPAD_SINGLE1;
    else if(adc_valume < 590)
        level = KPAD_SINGLE2;
    else if(adc_valume < 670)
        level = KPAD_SINGLE3;
    else
        level = KPAD_SINGLE4;
    __log("------single_value=%d---\n", adc_valume);

    return level;
}
static __u32 adc_key_scan_X2()
{
    __s32 adc_valume;
    //static __s32 adc_valume_prev=0;
    __u32 key = 0;
    adc_valume = get_adc_valume();
    //if(abs(adc_valume-adc_valume_prev)>2)
    //	{
    //     __log("ad_key_value=%d\n",adc_valume);
    //     adc_valume_prev=adc_valume;
    //	}
    //if(adc_valume!=2047)
    // __log("ad_key_value=%d\n",adc_valume);
    __msg("ad_key_value=%d\n",adc_valume);
    if(adc_valume < 1820)
    {
        esKRNL_TimeDly(2);
        adc_valume = get_adc_valume();
        if(adc_valume < 1820)
        {
#if 0
            if(adc_valume >= 10 && adc_valume < 200) //130
            {
                key = KPAD_DOWN ;
            }
            else if(adc_valume >= 200 && adc_valume < 335) //267
            {
                key = KPAD_MENU ;
            }
            else if(adc_valume >= 345 && adc_valume < 465) //409
            {
                key = KPAD_ENTER;
            }
            else if(adc_valume >= 475 && adc_valume < 600) //541
            {
                key = KPAD_MODE;
            }
            else if(adc_valume >= 610 && adc_valume < 730) //672
            {
                key = KPAD_UP;
            }
            else if(adc_valume >= 740 && adc_valume < 900) //805
            {
                key = KPAD_RIGHT;
            }
#else	// when pa2 config as rx
            /*

            	KPAD_MENU,
            KPAD_UP,
            KPAD_DOWN,
            KPAD_ENTER,
            KPAD_MODE,
            KPAD_PHOTO,
            KPAD_POWER,
            KPAD_POWEROFF
            */
            if(adc_valume >= 80 && adc_valume < 380) //184
            {
                key = KPAD_PREV;//KPAD_ENTER;//KPAD_PREV;//KPAD_PREV;//KPAD_LEFT;//KPAD_DOWN;
            }
            else if(adc_valume >= 380 && adc_valume < 780) //367
            {
                key = KPAD_NEXT;//KPAD_PREV;//KPAD_ENTER;
            }
            else if(adc_valume >= 780 && adc_valume < 1100) //549
            {
                key = KPAD_ENTER; // KPAD_NEXT;//KPAD_MODE;
            }
            else if(adc_valume >= 1100 && adc_valume < 1400) //738
            {
                key = KPAD_MODE;//KPAD_NEXT;//KPAD_NEXT;//KPAD_RIGHT;//KPAD_UP;
            }
            //	else if(adc_valume>=1010&&adc_valume<1190)//1100
            //	{
            //		key = KPAD_UP;
            //	}
            //	else if(adc_valume>=1200&&adc_valume<1500)//1280
            //	{
            //		key = KPAD_RIGHT;
            //	}
#endif
            if(key)
            {
                adc_key_down = 1;
            }
        }
        //eLIBs_printf(">>>&&&&&&&&&&&&&& adc_valume_x2 = %d &&&&&&&&&&&&&\n",adc_valume);
    }
    return key;
}
static __u32 adc_key_scan_Y1()
{
    __s32 adc_valume;
    __u32 key = 0;
    adc_valume = get_adc_valume();
	__msg("ad_key_value=%d\n",adc_valume);
    if(adc_valume <= 1820)
    {
        esKRNL_TimeDly(2);
        adc_valume = get_adc_valume();
        if(adc_valume <= 1820)
        {
            if(adc_valume >= 0 && adc_valume < 60) //tv 150 // fm25
            {
                key = KPAD_NUM1;
            }
            else if(adc_valume >= 100 && adc_valume < 200) //movie 150
            {
                key = KPAD_MUSIC;
            }
            else if(adc_valume >= 250 && adc_valume < 350) //movie 291
            {
                key = KPAD_MOVIE;
            }
            else if(adc_valume >= 400 && adc_valume < 500) //play 442
            {
                key = KPAD_MENU;//m
            }
            else if(adc_valume >= 500 && adc_valume < 600) //next 574
            {
                key = KPAD_RETURN;//r
            }
            else if(adc_valume >= 650 && adc_valume < 750) //right 704
            {
            }
            else if(adc_valume >= 800 && adc_valume < 900) //eq+846
            {
            }
            else if(adc_valume >= 950 && adc_valume < 1050) //eq-977
            {
                key = KPAD_LEFT;//r
            }
            else if(adc_valume >= 1050 && adc_valume < 1150) //return 1080
            {
                key = KPAD_RIGHT;//l
            }
            else if(adc_valume >= 1150 && adc_valume < 1250) //menu 1198
            {
            }
            else //if(adc_valume>=1710&&adc_valume<1820)
            {
                key = 0;
            }
            if(key)
            {
                adc_key_down = 1;
            }
        }
        eLIBs_printf("&&&&&&&&&&&&&& adc_valume_y1 = %d &&&&&&&&&&&&&\n", adc_valume);
    }
    return key;
}
static __u32 adc_key_scan_Y2()
{
    __s32 adc_valume;
    __u32 key = 0;
    adc_valume = get_adc_valume();
    if(adc_valume <= 1820)
    {
        esKRNL_TimeDly(2);
        adc_valume = get_adc_valume();
        if(adc_valume <= 1820)
        {
            if(adc_valume >= 0 && adc_valume < 60)
            {
                key = KPAD_NUM5;
            }
            if(key)
            {
                adc_key_down = 1;
            }
        }
        eLIBs_printf("&&&&&&&&&&&&&& adc_valume_y2 = %d &&&&&&&&&&&&&\n", adc_valume);
    }
    return key;
}

//ȫ�������ɿ������ڲ��䷢��δ���͵�key up��Ϣ
static void matrix_match_key_down(void)
{
    __s32 i;
    __s32 key_cnt;

    key_cnt = sizeof(g_key_down_tbl) / sizeof(g_key_down_tbl[0]);

    for(i = 0 ; i < key_cnt ; i++)
    {
        while(g_key_down_tbl[i] > 0)
        {
            matrix_key_up(i);
        }
    }
}

/********************************************************************************************************
* Function:    power_off_timer
* Description:
* Input��
* Output��
* Other��
*********************************************************************************************************/
static __u8  power_on_end = 0;
//__hdle hPowerOn = NULL;
static __u8 pw_key_flag = 0;

static void power_off_timer(void *arg)
{
    static int count = 0;
    static int count_relase = 0;
    ES_FILE *power_hd;
    //eLIBs_printf("power_off_timer 111\n");
#if 0
    if(first_poweron_flag == 0)
    {
        first_power_on_cnt++;
        if(first_power_on_cnt > 20)
        {
            first_poweron_flag = 1;
        }
    }
#endif
    if(pw_off)
    {

        if(esPINS_ReadPinData(pw_off, 0))
        {
            //���������ɿ�����
            if(power_on_end == 0 )
                return;
            //   eLIBs_printf("power_off_timer esPINS_ReadPinData count = %d\n",count);
            if(is_power_off == EPDK_FALSE)
            {
                if(++count >= 2)
                {
                    __log("----pw_off_key\n");

                    //matrix_key_down(KPAD_POWEROFF);
                    is_power_off = EPDK_TRUE;
                    count = 0;
                    pw_key_flag = 1;
                }
            }
            count_relase = 0;
        }
        else
        {

            if(power_on_end == 0 )
            {
                power_on_end = 1;
            }

            if(is_power_off == EPDK_TRUE )
            {
                if(pw_key_flag)
                {
                    pw_key_flag = 0;
                    //matrix_key_up(KPAD_POWEROFF);
                }
            }

#if 0
            if(is_power_off == EPDK_TRUE )
            {
                if(++count_relase >= 4)
                {
                    count_relase = 0;
                    eLIBs_fioctrl(power_hd, DRV_POWER_CMD_POWER_OFF, 0, 0);
                    eLIBs_fclose( power_hd );
                    // esPINS_WritePinData(hPowerOn, 0, 0);
                }

            }
#endif
            count = 0;

        }
    }
}
__s32 adc_key_init()
{
    RK_Init();
    RK_SetFifoDepth(RK_FIFO_DEPTH_08);
    RK_SetSampleRate(RK_SAMPLE_RATE_16K);
    RK_EnableInt(RK_DATA_IRQ);

    //RK_SelectChannel(RK_CHANNEL_Y1);
    //RK_ClearFifo();
    //RK_SelectChannel(RK_CHANNEL_Y2);
    //RK_ClearFifo();
    //RK_SelectChannel(RK_CHANNEL_X1);
    //RK_ClearFifo();
    RK_SelectChannel(RK_CHANNEL_X1);
    RK_ClearFifo();
}
/********************************************************************************************************
* Function:    matrix_key_thread
* Description: matrix key running thread
* Input��
* Output��
* Other��
*********************************************************************************************************/
static __u8 read_single_flag = 1;
__u32 get_single_value(void)
{

    //__u32 value;
    ////esKRNL_TimeDly(1);
    // RK_SelectChannel(RK_CHANNEL_X2);//x1
    // RK_ClearFifo();
    // esKRNL_TimeDly(2);//3 //1
    //value=adc_single_scan_X1();
    //esKRNL_TimeDly(2);//3 //1
    read_single_flag = 1;
    return sinle_level_value;


}

static void matrix_key_thread(void *p_arg)
{
    __u32 old_key, new_key, key = 0;
    __s32 delay;

    //���¶��������Զ�����
    __s32 adc_valume;
    //static __u32 lopp_cnt=100;
    static __u32 flag = 0;

    if(adc_key_init_ok == 0)
    {
        //�����debugģʽ�����Զ����ԣ������ϵͳ��������Ϣ
#if 0
        while(key_time_count < 15)
        {
            key_time_count++;
            esKRNL_TimeDly(50);
        }
#endif
        adc_key_init();
        adc_key_init_ok = 1;
    }

    RK_SelectChannel(RK_CHANNEL_X1);
    RK_ClearFifo();

    while (1)
    {
        if (esKRNL_TDelReq(OS_PRIO_SELF) == OS_TASK_DEL_REQ)
        {
            break;
        }
        esKRNL_TimeDly(1);

        if(adc_key_down == 1)
        {
            esKRNL_TimeDly(3);
            adc_key_down = 0;
            //ex_key_down = 0;
        }

        RK_SelectChannel(RK_CHANNEL_X1);
        RK_ClearFifo();
        old_key = adc_key_scan_X2();

#if 0
        if(1 == g_pw_off_support && 0 == old_key)
        {
            __s32 d1 = 0;
            d1 = esPINS_ReadPinData(pw_off, 0);
            if (d1)
            {
                old_key = KPAD_POWER;
            }
        }
#endif
        delay = 0;
        while (old_key) //���ѭ��ɨ�赽һ����ֵ!!!
        {
            esKRNL_TimeDly(3);
            //eLIBs_printf(">>>�ڲ�ѭ��ɨ! old_key = %d\n",old_key);


            RK_SelectChannel(RK_CHANNEL_X1);
            RK_ClearFifo();
            esKRNL_TimeDly(2);//3 //1
            new_key = adc_key_scan_X2();
            //__log("--KEY=%x\n",new_key);
#if 0
            if(1 == g_pw_off_support && 0 == new_key)
            {
                __s32 d1 = 0;

                d1 = esPINS_ReadPinData(pw_off, 0);
                if (d1)
                {
                    new_key = KPAD_POWER;
                }
            }
#endif
            if (new_key) /* ����һ����Чֵ */
            {
                //0831  modify   fankun
                // lopp_cnt=100;
                prev_single_level_value = 0x55;
                //eLIBs_printf(">>>�ڲ�ѭ��ɨ�赽һ����ֵ!!! new_key = %d,old_key = %d\n",new_key,old_key);
                /* ǰ�����ζ�����ֵ��ͬ������ǰ�������ֵ��Ч */
                if ((new_key ^ old_key) && old_key)
                {
                    __msg("new_key=%d\n", new_key);
                    __msg("old_key=%d\n", old_key);
                    break;
                }
                __here__;

                delay += period;
                if (!(delay ^ key_down_delay))
                {
                    /* ������Ϣǰ����Ƿ��ӳ��Ƿ�ﵽ�����趨����ֵ */
                    key = new_key;
                    matrix_key_down(key);
                    delay = 0;
                }
            }
            else if (key) /* �������� */
            {
                matrix_key_up(key);
                key = 0;
                break; /* �˳���ѭ�� */
            }
            else /* ����һ����Чֵ */
            {
                //__here__;
                __wrn("____________________new_key = %d\n", new_key);
                delay = 0;

                matrix_match_key_down();
                break;
            }
        }

        if(read_single_flag)
        {
            read_single_flag = 0;
            RK_SelectChannel(RK_CHANNEL_X2);//x1
            RK_ClearFifo();
            esKRNL_TimeDly(2);
            sinle_level_value = adc_single_scan_X1();

        }
        ////////////////////////////////////////////////////////////////////////
        // RK_SelectChannel(RK_CHANNEL_X2);//x1
        // RK_ClearFifo();
        // esKRNL_TimeDly(2);//3 //1
        // sinle_level_value=adc_single_scan_X1();
        // __log("----jhdbg0217=%d----",sinle_level_value);
        /////////////////////////////////////////////////////////////////////////
#if 0
        if(++lopp_cnt > 200)
        {
            __key_msg_t msg1;

            if(flag == 0)
            {

                __log("----down----\n");
                lopp_cnt = 193;
                flag = 1;
                RK_SelectChannel(RK_CHANNEL_X2);//x1
                RK_ClearFifo();
                esKRNL_TimeDly(2);//3 //1
                sinle_level_value = adc_single_scan_X1();
                msg1.key_value = sinle_level_value;
                msg1.flag = 1;
                //set_single_value(sinle_level_value);
                if(prev_single_level_value != sinle_level_value)
                    dev_matrix_key_ioctrl(0, DRV_KEY_CMD_PUTKEY, 0, &msg1);
                // prev_single_level_value=sinle_level_value;
            }

            else
            {

                __log("----up----\n");
                lopp_cnt = 0;
                flag = 0;
                msg1.key_value = sinle_level_value;
                msg1.flag = 0;
                if(prev_single_level_value != sinle_level_value)
                    dev_matrix_key_ioctrl(0, DRV_KEY_CMD_PUTKEY, 0, &msg1);
                if(first_poweron_flag == 1)
                    prev_single_level_value = sinle_level_value;
            }
        }
#endif
    }
}
__s32 matrix_iic_key_init(void)
{
    __wrn("*******drv_key_ic_init********************\n");
#if 0
    input_y2 = Request_GPIO((const char *)"input_key", 2);
    if (input_y2 == 0)
    {
        __wrn("request input io failed\n");
        return EPDK_FAIL;
    }
    if(input_y2 == 0)
    {
        __wrn("input_y2 fail\n");
        return EPDK_FAIL;
    }
    if( iic_file == NULL )
    {
        iic_file = (ES_FILE *)eLIBs_fopen("b:\\BUS\\twi2", "r+");
    }
    if(iic_file == NULL)
    {
        __wrn("OPEN i2c device fail\n");
        return EPDK_FAIL;
    }
    eLIBs_fioctrl(iic_file, TWI_SET_SCL_CLOCK, 0, (void *)TWI_SCLK_50KHZ);
    PrevKeyValue = NOKEY;
#endif

    return EPDK_OK;
}
static __hdle reqInterGpio(__u8 *name, __u8 pin, __u8 pull)
{
    user_gpio_set_t  PinStat;
    __hdle			 hPin;

    eLIBs_strcpy(PinStat.gpio_name, name);
    PinStat.port	  = 4;
    PinStat.port_num  = pin;
    PinStat.mul_sel   = 0;
    PinStat.pull	  = pull;
    PinStat.drv_level = 1;
    PinStat.data	  = 0;
    hPin = esPINS_PinGrpReq(&PinStat, 1);
    return hPin;
}

/********************************************************************************************************
* Function:    matrix_key_init
* Description: initial matrix key
* Input��
* Output��
* Other��
*********************************************************************************************************/


__s32 matrix_key_init(void)
{
    __s32            ret;

    user_gpio_set_t gpio_set[1];
#if 0
    /* ����input_row1 */
    input_row1 = Request_GPIO((const char *)"input_row1", 2);
    if (input_row1 == 0)
    {
        __wrn("request input io failed\n");
        return EPDK_FAIL;
    }

    input_row2 = Request_GPIO((const char *)"input_row2", 2);
    if (input_row2 == 0)
    {
        __wrn("request input io failed\n");
        return EPDK_FAIL;
    }
    input_row3 = Request_GPIO((const char *)"input_row3", 2);
    if (input_row3 == 0)
    {
        __wrn("request input io failed\n");
        return EPDK_FAIL;
    }
#endif
    /* ����input_row2 */

#if 0
    if(1)
    {
        x2_output = Request_GPIO((const char *)"x2_output", 1);

        if(x2_output)
        {
            esPINS_WritePinData(x2_output, 0, NULL);
        }

        y1_output = Request_GPIO((const char *)"y1_output", 1);
        if(x2_output)
        {
            esPINS_WritePinData(y1_output, 0, NULL);
        }
    }
#endif
    //#if 0
    //eLIBs_printf("request Power Off pin\n");



    eLIBs_memset(gpio_set, 0, sizeof(user_gpio_set_t));
#if 0
    ret = esCFG_GetKeyValue("power_para", "power_on", (int *)gpio_set, sizeof(user_gpio_set_t) / 4);
    if (ret)
    {
        __wrn("fetch para from script failed\n");
        //goto err_out;
    }

    hPowerOn = esPINS_PinGrpReq(gpio_set, 1);
    if (!hPowerOn)
    {
        __wrn("request power on pin failed\n");
        //goto err_out;
    }
    __log("--power_on-pin\n");
#endif
    if(1 == g_pw_off_support)
    {
        /* ����Power Off */
        ret = esCFG_GetKeyValue("matrixkey_para", "pw_off", (int *)gpio_set, sizeof(user_gpio_set_t) / 4);
        if (!ret)
        {
            pw_off = esPINS_PinGrpReq(gpio_set, 1);//reqInterGpio("pw_off",14,0);
            if (!pw_off)
            {
                __msg("request Power Off pin failed\n");
                return EPDK_FAIL;
            }

        }
        else
        {
            __wrn("fetch para from script failed\n");
            return EPDK_FAIL;
        }

    }
    /* ��ȡɨ������ */
    ret = esCFG_GetKeyValue("matrixkey_para", "period", &period, 1);
    if (ret)
    {
        __wrn("fetch para: period from script failed\n");
        period = 2;
    }
    __msg("matrix key update period: %d\n", period);

    /* ��ȡ�ػ�ʱ�� */
    ret = esCFG_GetKeyValue("matrixkey_para", "pw_off_time", &pw_off_time, 1);
    if (ret)
    {
        __wrn("fetch para: pw_off_time from script failed\n");
        pw_off_time = 2000;
    }
    __msg("power off time: %d\n", pw_off_time);

    /* ��ȡ���������ӳٵ�ʱ�� */
    ret = esCFG_GetKeyValue("matrixkey_para", "key_down_delay", &key_down_delay, 1);
    if (ret)
    {
        __wrn("fetch para: key_down_delay from script failed\n");
        key_down_delay = 1 * period;
    }

    __msg("key down delay: %d\n", key_down_delay);
#if 1
    /* ����timer */
    timer = esKRNL_TmrCreate(
                500,
                OS_TMR_OPT_PRIO_HIGH | OS_TMR_OPT_PERIODIC,
                (OS_TMR_CALLBACK)power_off_timer,
                NULL);
    if (timer)
    {
        esKRNL_TmrStart(timer);
    }
#endif
#if 0
    matrix_iic_key_init();
    //power_on_info_exchip(0x01,0x00,1);
#endif
    //eLIBs_printf(">>>>>>>>>>>>>>>>>>>>>>>%d,%s\n",__LINE__,__FILE__);
    matrix_key_tid = esKRNL_TCreate(matrix_key_thread, 0, 0x400, KRNL_priolevel3);

    __msg("matrix key init finish\n");

    return EPDK_OK;
}

/********************************************************************************************************
* Function:    matrix_key_exit
* Description: exit matrix key
* Input��
* Output��
* Other��
*********************************************************************************************************/
__s32 matrix_key_exit(void)
{
    esPINS_PinGrpRel(input_row1, 0);
    esPINS_PinGrpRel(input_row2, 0);
    if(input_y2)
    {
        esPINS_PinGrpRel(input_y2, 0);
        input_y2 = 0;
    }
    if(1 == g_pw_off_support)
    {
        esPINS_PinGrpRel(pw_off, 0);
    }

    if(iic_file)
    {
        eLIBs_fclose(iic_file);
        iic_file = 0;
    }

    esKRNL_TDel(matrix_key_tid);
    if(timer)
    {
        esKRNL_TmrStop(timer, OS_TMR_OPT_PRIO_HIGH | OS_TMR_OPT_PERIODIC, NULL);
        esKRNL_TmrDel(timer);
        timer = NULL;
    }

    RK_Exit();
    __msg("matrix key exit finish\n");

    return EPDK_OK;
}
