
#ifndef __APP_FM_H__
#define  __APP_FM_H__

__s32 app_fm_create(root_para_t *para);

void  fm_cmd2parent(H_WIN hwin, __s32 id, __s32 data1, __s32 data2);

#endif

