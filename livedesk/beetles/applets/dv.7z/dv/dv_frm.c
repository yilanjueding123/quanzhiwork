/*
*********************************************************************************************************
*											        ePDK
*						            the Easy Portable/Player Develop Kits
*									           home app sample
*
*						        	(c) Copyright 2006-2009, China
*											 All Rights Reserved
*
* File    : home.c
* By      : lyn
* Version : V1.00
*********************************************************************************************************
*/

#include "dv_i.h"
#include "dv_uipara.h"
#include "dv_frm.h"
#include "dv_common.h"
#include "app_root_scene.h"

#if  0
//#define __here__            eLIBs_printf("@L%d(%s)\n", __LINE__, __FILE__);
//#define __msg(...)    		(eLIBs_printf("MSG:L%d(%s):", __LINE__, __FILE__),                 \
//						     eLIBs_printf(__VA_ARGS__)									        )
//#define __inf(...)    		(eLIBs_printf("MSG:L%d(%s):", __LINE__, __FILE__),                 \
//								 eLIBs_printf(__VA_ARGS__)											)
#define __mymsg(...)    		(eLIBs_printf("MSG:L%d(%s):", __LINE__, __FILE__),                 \
									 eLIBs_printf(__VA_ARGS__)											)
#else
#define __msg(...)   
#define __inf(...)
#define __mymsg(...)
#endif

typedef struct   valuet
{
    __u32   single_value;
    __u32   resverd;
} single_t;

typedef struct __auto_search
{
	__u8 channel;
	__u8 search_end;
	__u8 prev_value;
	__u8 current_value;
	__u32 max_value;
	__u8 max_channel;
	__s32 key_save_flg;
	__s32 save_cnt;
}auto_search;

typedef enum
{
	KEY_NONE_ACTION = 0,
	KEY_PRESS_ACTION,
}KEY_FLAG;

static auto_search *spi_auto_srch;
static KEY_FLAG key_flag = KEY_NONE_ACTION;

static __u32   dv_single_level = 0;
static __u32   dv_prevsingle_level = 0xff;
static __u32 next_signal_level, prev_signal_level;


#ifdef APP_DV_HBAR
static __s32 __app_dv_draw_rec_time_hbar(__gui_msg_t *msg, __u32 time);
static __s32 __app_dv_draw_rec_batt_status(H_LYR hlyr);
extern __u32  channel_freq[32];
#endif


static void  __dv_get_time_mark_index(__date_t date, __time_t time, __u8 *mark, __u8 level)
{
    mark[0]  =   date.year / 1000;
    mark[1]  =  (date.year - mark[0] * 1000) / 100;
    mark[2]  =   (date.year - mark[0] * 1000 - mark[1] * 100) / 10;
    mark[3]  =   date.year - mark[0] * 1000 - mark[1] * 100 - mark[2] * 10;
    mark[4]  =   11;
    mark[5]  =   date.month / 10;
    mark[6]  =   date.month - mark[5] * 10;
    mark[7]  =   11;
    mark[8]  =   date.day / 10;
    mark[9]  =   date.day - mark[8] * 10;
    mark[10] =   12;
    mark[11] =  time.hour / 10;
    mark[12] =   time.hour - mark[11] * 10;
    mark[13] =   10;
    mark[14] =   time.minute / 10;
    mark[15] =   time.minute - mark[14] * 10;
    mark[16] =   10;
    mark[17] =   time.second / 10;
    mark[18] =   time.second - mark[17] * 10;



    if(level == 1)
    {
        __u8 i = 0;
        for(i = 0; i <= 18; i++)
        {
            mark[i] += 20;

        }
    }
}

__s32   __dv_get_last_file(char *dir)
{

    __s32			  cnt = 0;
    char			  name[1024];
    char 		  *tmp_sfx;
    ES_DIR		  *tmp_dir;
    ES_DIRENT	  *tmp_dirent;
    __s32  file_index = 0;

	//__mymsg("__dv_get_last_file, dir:%s\n", *dir);
    tmp_dir = eLIBs_opendir(dir);
    if(tmp_dir == NULL)
    {
    	
		//__mymsg("__dv_get_last_file\n");
    	__here__;
        return 0;
    }
    eLIBs_memset(&name, 0x00, 1024);
	__here__;
    while(NULL != (tmp_dirent = eLIBs_readdir(tmp_dir)))
    {
        if(tmp_dirent->fatdirattr & FSYS_ATTR_DIRECTORY)
        {
            // �Ƿ��ļ�
            if(tmp_dirent->d_name[0] == '.')
            {
            	__here__;
                continue;
            }
        }
        else
        {
            tmp_sfx = eLIBs_strchrlast((char *)tmp_dirent->d_name, '.');
            if(NULL == tmp_sfx)
            {
                continue;
            }
			__here__;
			if(Cvr_DvGetWorkMode() == WORK_MODE_REC)
			{
	            if(eLIBs_stricmp(tmp_sfx, FILE_NAME_SUFFIX) == 0)
	            {
	                if(0 < eLIBs_strcmp((char *)tmp_dirent->d_name, name))
	                {
	                    cnt++;
	                    eLIBs_strcpy(name, (char *)tmp_dirent->d_name);
	                }
	            }
			}
			else if(Cvr_DvGetWorkMode() == WORK_MODE_CAM)
			{
				//__mymsg("FILE_NAME_IMAGE: %s\n", FILE_NAME_IMAGE);
	            if(eLIBs_stricmp(tmp_sfx, FILE_NAME_IMAGE) == 0)
	            {
	                if(0 < eLIBs_strcmp((char *)tmp_dirent->d_name, name))
	                {
	                    cnt++;
	                    eLIBs_strcpy(name, (char *)tmp_dirent->d_name);
	                }
	            }
			}
        }
    }
    eLIBs_closedir(tmp_dir);
	__here__;
    if(cnt == 0)
    {
    	__here__;
        return 0;//EPDK_FAIL;
    }
    file_index = 1000 * (name[3] - 0x30) + 100 * (name[4] - 0x30) + 10 * (name[5] - 0x30) + name[6] - 0x30;

    return file_index;

}
static __s32   __dv_get_first_file(char *dir, char *file_name, char *invalid_file)
{
    __s32           cnt = 0;
    char            name[1024];
    char           *tmp_sfx;
    ES_DIR         *tmp_dir;
    ES_DIRENT      *tmp_dirent;

    tmp_dir = eLIBs_opendir(dir);
    if(tmp_dir == NULL)
    {
        return EPDK_FAIL;
    }
    eLIBs_memset(&name, 0xFF, 1024);

    while(NULL != (tmp_dirent = eLIBs_readdir(tmp_dir)))
    {
        if(tmp_dirent->fatdirattr & FSYS_ATTR_DIRECTORY)
        {
            // �Ƿ��ļ�
            if(tmp_dirent->d_name[0] == '.')
            {
                continue;
            }
        }
        else
        {
            tmp_sfx = eLIBs_strchrlast((char *)tmp_dirent->d_name, '.');
            if(NULL == tmp_sfx)
            {
                continue;
            }
            if(invalid_file != NULL)
            {
                //������ǰ����¼���ļ�
                if(0 == eLIBs_strcmp(invalid_file, (char *)tmp_dirent->d_name))
                {
                    continue;
                }
            }
            if(eLIBs_stricmp(tmp_sfx, FILE_NAME_SUFFIX) == 0)
            {
                if(0 < eLIBs_strcmp(name, (char *)tmp_dirent->d_name))
                {
                    cnt++;
                    eLIBs_strcpy(name, (char *)tmp_dirent->d_name);
                }
            }
        }
    }
    eLIBs_closedir(tmp_dir);

    if(cnt == 0)
    {
        return EPDK_FAIL;
    }
    eLIBs_strcpy(file_name, dir);
    eLIBs_strcat(file_name, "\\");
    eLIBs_strcat(file_name, name);

    return EPDK_OK;

}



static void dv_dialog_creat( dv_frmwin_para_t *dv_frm_ctrl, RECT *dialoag_rect, HTHEME bg_res, __u32 string_id)
{
    char str[64] ;
    GUI_RECT gui_rect ;

    if(dv_frm_ctrl->dialoag_lyr_hdl)
    {
        return;
    }

    dv_frm_ctrl->dialoag_lyr_hdl =  dv_layer_create( dialoag_rect, DISP_LAYER_WORK_MODE_NORMAL);
    GUI_LyrWinSetSta(dv_frm_ctrl->dialoag_lyr_hdl, GUI_LYRWIN_STA_ON);
    GUI_LyrWinSetTop(dv_frm_ctrl->dialoag_lyr_hdl);

//    __msg("after create dialoag_lyr_hdl = %x\n", dv_frm_ctrl->dialoag_lyr_hdl);

    if (GUI_LyrWinGetSta(GUI_WinGetLyrWin(dv_frm_ctrl->frmwin_hdl)) == GUI_LYRWIN_STA_SUSPEND)
    {
        esKRNL_TimeDly(1);
        if (GUI_LyrWinGetSta(GUI_WinGetLyrWin(dv_frm_ctrl->frmwin_hdl)) == GUI_LYRWIN_STA_SUSPEND)
            return ;
    }

    GUI_LyrWinSel(dv_frm_ctrl->dialoag_lyr_hdl);
    GUI_SetFont(dv_frm_ctrl->font);
    GUI_UC_SetEncodeUTF8();
    //GUI_SetColor(dv_frm_ctrl->txt_color);//GUI_DARKRED

    GUI_SetColor(GUI_DARKRED);

    GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->msg_box_bg), 0, 0);

    dsk_langres_get_menu_text(string_id, str, GUI_TITLE_MAX);
    gui_rect.x0 = 0 ;
    gui_rect.y0 = 0 ;
    gui_rect.x1 = dialoag_rect->width - 1;
    gui_rect.y1 = dialoag_rect->height - 1;

    GUI_DispStringInRect(str, &gui_rect, GUI_TA_HCENTER | GUI_TA_VCENTER);
    // creat timer for timer out
    GUI_SetTimer(dv_frm_ctrl->frmwin_hdl, TIMER_DIALOAG_TIMEOUT_ID, 50, NULL);


}


static void dv_dialog_destroy( dv_frmwin_para_t *dv_frm_ctrl)
{

    GUI_KillTimer(dv_frm_ctrl->frmwin_hdl, TIMER_DIALOAG_TIMEOUT_ID);
    if(dv_frm_ctrl->dialoag_lyr_hdl)
    {
//        __msg("after destroy dialoag_lyr_hdl = %x\n", dv_frm_ctrl->dialoag_lyr_hdl);

        dv_layer_destroy( dv_frm_ctrl->dialoag_lyr_hdl );
        dv_frm_ctrl->dialoag_lyr_hdl = NULL ;
    }

}


///...///



static void  __dv_init(dv_frmwin_para_t *dv_frm_ctrl)
{
    __dv_config_t       tmp_config;
    __lotus_overlay_src_init_t  tmp_src;

    //__msg("__dv_init\n");

    eLIBs_memset(&tmp_config, 0 , sizeof(tmp_config) );
    Cvr_DvOpen();
    dv_frm_ctrl->cur_state = DV_ON_REC ;

    if(dv_frm_ctrl->cur_state == DV_ON_REC)
    {
        tmp_config.work_mode    = WORK_MODE_REC;
        tmp_config.rec_quality  = RECORD_QUALITY_1280_720 ;
    }
    else if(dv_frm_ctrl->cur_state == DV_ON_CAM)
    {
        tmp_config.work_mode    = WORK_MODE_CAM;
		tmp_config.cam_quality = CAMERA_QUALITY_200;
    }
    __here__;

    Cvr_DvConfigPara(&tmp_config);
    // ����ʱ��ˮӡ����Դ


    __here__;

    //From Kok
    cvr_water_mark_get_overlay_data(&tmp_src, 0);

//    __msg("ID = %x\n", tmp_src.srcPic[0].ID);
//    __msg("size = %d\n", tmp_src.srcPic[0].size);

//    __msg("ID = %x\n", tmp_src.srcPic[1].ID);
//    __msg("size = %d\n", tmp_src.srcPic[1].size);

//    __msg("ID = %x\n", tmp_src.srcPic[2].ID);
//    __msg("size = %d\n", tmp_src.srcPic[2].size);

    //From Kok
    dv_frm_ctrl->user_data->circle_rec_time_interval = 0;//3 * 60; // �ر�ѭ��¼��
    dv_frm_ctrl->user_data->record_mute_enable = 0;
    dv_frm_ctrl->user_data->water_mark_enable = 0;//0;//1;


    dv_frm_ctrl->sys_date.year = 2015;
    dv_frm_ctrl->sys_date.month = 1;
    dv_frm_ctrl->sys_date.day = 1;


//    __msg("circle_rec_time_interval = %d\n", dv_frm_ctrl->user_data->circle_rec_time_interval);
//    __msg("record_mute_enable       = %d\n", dv_frm_ctrl->user_data->record_mute_enable);
//    __msg("water_mark_enable        = %d\n", dv_frm_ctrl->user_data->water_mark_enable);

    Cvr_DvSetOverlaySrc(&tmp_src, 0);
    // ������ͨ¼���ļ�����
    Cvr_DvChangeNamePrefix(FILE_NAME_PRIX);

}

static void  _dv_exit(dv_frmwin_para_t *dv_ctrl)
{
    __msg("_dv_exit\n");
    Cvr_DvClose();
}

#if (CVR_TVOUT_ENABLE == 1)
static void __dv_tv_plugin(dv_frmwin_para_t *dv_frm_ctrl)
{
    RECT        rect;
    ES_FILE    *display;

    dsk_display_off();
    dsk_display_set_format(LION_DISP_TV_NTSC);

    display = eLIBs_fopen("b:\\DISP\\DISPLAY", "r+");
    if(display == NULL)
    {
        __wrn("can not open display driver\n");
    }
    switch(dv_frm_ctrl->cur_state)
    {
    case DV_ON_REC:
    case DV_ON_CAM:
    case DV_ON_REC_SET:
    case DV_ON_CAM_SET:
    {
        rect.x      = 30;
        rect.y      = 20;
        rect.width  = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_WIDTH, 0, NULL) - 60;
        rect.height = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_HEIGHT, 0, NULL) - 40;
        Cvr_DvSetShowRect(rect, 0);
        Cvr_DvSetShowRect(rect, 1);
        break;
    }
    default:
        break;
    }

    // need to do  handle UI when turn from lcd->tv

    dsk_display_on(DISP_OUTPUT_TYPE_TV);
    eLIBs_fclose(display);
}

static void __dv_tv_plugout(dv_frmwin_para_t *dv_frm_ctrl)
{
    RECT        rect;
    ES_FILE    *display;

    dsk_display_off();
    dsk_display_set_format(LION_DISP_LCD);
    display = eLIBs_fopen("b:\\DISP\\DISPLAY", "r+");
    if(display == NULL)
    {
        __wrn("can not open display driver\n");
    }
    switch(dv_frm_ctrl->cur_state)
    {
    case DV_ON_REC:
    case DV_ON_CAM:
    case DV_ON_REC_SET:
    case DV_ON_CAM_SET:
    {
        rect.x      = 0;
        rect.y      = 0;
        rect.width  = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_WIDTH, 0, NULL);
        rect.height = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_HEIGHT, 0, NULL);
        Cvr_DvSetShowRect(rect, 0);
        Cvr_DvSetShowRect(rect, 1);
        break;
    }
    default:
        break;
    }

    // need to do  handle UI when turn from tv->lcd


    dsk_display_on(DISP_OUTPUT_TYPE_LCD);
    eLIBs_fclose(display);
}
#endif

#if (CVR_HDMI_ENABLE == 1)
static void __dv_hdmi_plugin(dv_frmwin_para_t *dv_frm_ctrl)
{
    __u32       tmp_len;
    RECT        rect;
    ES_FILE    *display;

    dsk_display_off();
    dsk_display_set_format(LION_DISP_HDMI_720P_50HZ);

    display = eLIBs_fopen("b:\\DISP\\DISPLAY", "r+");
    if(display == NULL)
    {
        __wrn("can not open display driver\n");
    }
    switch(dv_frm_ctrl->cur_state)
    {
    case DV_ON_REC:
    case DV_ON_CAM:
    case DV_ON_REC_SET:
    case DV_ON_CAM_SET:
    {
        rect.x      = 30;
        rect.y      = 20;
        rect.width  = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_WIDTH, 0, NULL) - 60;
        rect.height = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_HEIGHT, 0, NULL) - 40;
        Cvr_DvSetShowRect(rect, 0);
        Cvr_DvSetShowRect(rect, 1);
        break;
    }
    default:
        break;
    }

    // need to do  handle UI when turn from tv->lcd

    dsk_display_on(DISP_OUTPUT_TYPE_HDMI);
    eLIBs_fclose(display);
}

static void __dv_hdmi_plugout(dv_frmwin_para_t *dv_frm_ctrl)
{
    RECT        rect;
    ES_FILE    *display;

    dsk_display_off();
    dsk_display_set_format(LION_DISP_LCD);

    display = eLIBs_fopen("b:\\DISP\\DISPLAY", "r+");
    if(display == NULL)
    {
        __wrn("can not open display driver\n");
    }
    switch(dv_frm_ctrl->cur_state)
    {
    case DV_ON_REC:
    case DV_ON_CAM:
    case DV_ON_REC_SET:
    case DV_ON_CAM_SET:
    {
        rect.x      = 0;
        rect.y      = 0;
        rect.width  = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_WIDTH, 0, NULL);
        rect.height = eLIBs_fioctrl(display, DISP_CMD_SCN_GET_HEIGHT, 0, NULL);
        Cvr_DvSetShowRect(rect, 0);
        Cvr_DvSetShowRect(rect, 1);
        break;
    }
    default:
        break;
    }

    // need to do  handle UI when turn from tv->lcd

    dsk_display_on(DISP_OUTPUT_TYPE_LCD);
    eLIBs_fclose(display);
}
#endif

static __s32 __dv_timer_record_proc(void *p_arg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)p_arg;


    //From Kok
    //Because there is no rtc,please add it after rtc existed.
    //esTIME_GetTime(&dv_frm_ctrl->sys_time);
    //esTIME_GetDate(&dv_frm_ctrl->sys_date);
    dv_frm_ctrl->sys_date.year  = 2015;
    dv_frm_ctrl->sys_date.day   = 1;
    dv_frm_ctrl->sys_date.day   = 1;

    dv_frm_ctrl->sys_time.hour   = 10;
    dv_frm_ctrl->sys_time.minute = 10;
    dv_frm_ctrl->sys_time.second = 10;


    if(Cvr_DvGetRecState() != RECORD_STOP)
    {
        // ����ʱ��ˮӡ
        if(dv_frm_ctrl->user_data->water_mark_enable == 1)
        {
            dv_frm_ctrl->water_mark_para.total = 19;
            dv_frm_ctrl->water_mark_para.pos.x = 40;
            dv_frm_ctrl->water_mark_para.pos.y = 40;


            __dv_get_time_mark_index(dv_frm_ctrl->sys_date, dv_frm_ctrl->sys_time, dv_frm_ctrl->water_mark_para.IDlist, 0);
            Cvr_DvShowOverlay(&dv_frm_ctrl->water_mark_para, 0);
        }
        else
        {
            Cvr_DvShowOverlay(NULL, 0);
        }

        if(dv_frm_ctrl->recording_flash_flag)
        {
            __gui_msg_t new_msg ;
            new_msg.id			= GUI_MSG_PAINT,
                           new_msg.h_srcwin	= dv_frm_ctrl->frmwin_hdl;
            new_msg.h_deswin	= dv_frm_ctrl->frmwin_hdl;
            new_msg.dwReserved	= DV_PAINT_FLASH_ICON1;
            new_msg.dwAddData2	= 0;
            new_msg.p_arg		= NULL;

            GUI_SendAsyncMessage (&new_msg);
            dv_frm_ctrl->recording_flash_flag = 0 ;
        }
        else
        {
            __gui_msg_t new_msg ;
            new_msg.id			= GUI_MSG_PAINT,
                           new_msg.h_srcwin	= dv_frm_ctrl->frmwin_hdl;
            new_msg.h_deswin	= dv_frm_ctrl->frmwin_hdl;
            new_msg.dwReserved	= DV_PAINT_FLASH_ICON2;
            new_msg.dwAddData2	= 0;
            new_msg.p_arg		= NULL;

            GUI_SendAsyncMessage (&new_msg);
            dv_frm_ctrl->recording_flash_flag = 1 ;

        }

    }

    return EPDK_OK;
}

static void __dv_delete_first_file_thread(void *p_arg)
{
    __s32               ret;
    __s64               tmp_size;
    char                cur_file[1024];
    char                file_path[1024];
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)p_arg;

    while (1)
    {
        if(esKRNL_TDelReq(EXEC_prioself) == OS_TASK_DEL_REQ)
        {
            esKRNL_TDel(EXEC_prioself);
            break;
        }
        //������¼���ҵ�ǰ¼��ģʽΪѭ�����ǣ�user_data->circle_rec_time_interval = 0 ʱ¼�񲻸��ǣ�
        if((dv_frm_ctrl->rec_status != 0) && (dv_frm_ctrl->user_data->circle_rec_time_interval > 0))
        {
            tmp_size = eLIBs_GetVolFSpace(USER_DISK) - DISK_FULL_LEVEL;
            if(tmp_size <= (long long)0)    // ������
            {
                // ��ȡ��ǰ����¼���ļ���
                Cvr_DvGetFileName(cur_file, 0);
                ret = __dv_get_first_file(FILE_PATH, file_path, cur_file);
                if(ret == EPDK_OK)
                {
                    // ɾ���ļ�ʧ��
                    if(EPDK_FAIL == eLIBs_remove(file_path))
                    {
                        __log("remove file fail : %s, ret = %d \n", file_path, ret);
                    }
                }
            }
            esKRNL_TimeDly(100);
        }
        else
        {
            esKRNL_TimeDly(100);
        }
    }
}

static __s32 __dv_on_start_record( __gui_msg_t *msg)
{
    __s64               tmp_size;
    char                file_path[1024];
    dv_frmwin_para_t        	*dv_frm_ctrl;

    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
    // ѭ��¼���
    if(dv_frm_ctrl->user_data->circle_rec_time_interval > 0)
    {
//        __msg("*****dbg_0628_0*****\n");
        tmp_size = eLIBs_GetVolFSpace(USER_DISK) - DISK_FULL_LEVEL;
        if(tmp_size <= (long long)0)    // ������
        {
//            __msg("*****dbg_0628_1*****\n");
            // ��ȡ����¼�Ƶ��ļ����ǵ�ǰ¼���ļ���
            __dv_get_first_file(FILE_PATH, file_path, NULL);
            eLIBs_remove(file_path);
        }
//        __msg("*****dbg_0628_2*****\n");
        // ��ʼ¼��
        Cvr_DvStartRecord();
        dv_frm_ctrl->rec_status = 1;

    }
    else	// δ��ѭ��¼��
    {
        // ���������
        tmp_size = eLIBs_GetVolFSpace(USER_DISK) - DISK_FULL_LEVEL;
        if(tmp_size <= (long long)0)
        {
            // �������Ի���,need to do
            //__home_on_disk_full(msg);
        }
        else
        {
            // ��ʼ¼��
            Cvr_DvStartRecord();
            dv_frm_ctrl->rec_status = 1;
        }
    }
    return EPDK_OK;

}

static __s32 __dv_on_stop_record(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;

    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
    // ���ʱ��ˮӡ
    if(dv_frm_ctrl->user_data->water_mark_enable == 1)
    {
        dv_frm_ctrl->water_mark_para.total = 0;
        dv_frm_ctrl->water_mark_para.pos.x = 40;
        dv_frm_ctrl->water_mark_para.pos.y = 40;
        Cvr_DvShowOverlay(&dv_frm_ctrl->water_mark_para, 0);
    }
    dv_frm_ctrl->rec_status = 0;
    Cvr_DvStopRecord();
    eLIBs_memset((void *)(&dv_frm_ctrl->cur_rec_time), 0, sizeof((dv_frm_ctrl->cur_rec_time)));

    // need to do : draw recording time to zero

    return EPDK_OK;
}

static __s32 __dv_on_recording(__gui_msg_t *msg)
{
    __s64               tmp_size;
    dv_frmwin_para_t        	*dv_frm_ctrl;

    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
    // ѭ��¼���
    if(dv_frm_ctrl->user_data->circle_rec_time_interval > 0)
    {

        // ѭ��¼��
        if(Cvr_DvGetCurRecTime() >= dv_frm_ctrl->user_data->circle_rec_time_interval)
        {
            dv_frm_ctrl->rec_status = 0;
            Cvr_DvHaltRecord();
            eLIBs_memset((void *)(&dv_frm_ctrl->cur_rec_time), 0, sizeof((dv_frm_ctrl->cur_rec_time)));
            // ��ʼ¼��
            Cvr_DvStartRecord();
            dv_frm_ctrl->rec_status = 1;

        }
    }
    // δ��ѭ��¼�������10����ѭ��¼�񣬴�������ֹͣ¼��
    else
    {
        tmp_size = eLIBs_GetVolFSpace(USER_DISK) - DISK_FULL_LEVEL;
        if(tmp_size <= (long long)0)    // ������
        {
            dv_frm_ctrl->rec_status = 0;
            Cvr_DvStopRecord();
            eLIBs_memset((void *)(&dv_frm_ctrl->cur_rec_time), 0, sizeof((dv_frm_ctrl->cur_rec_time)));

            // ���³�����ʾͼ��
            // need to do :  disk full dialoag ;
        }
        else
        {
            if(Cvr_DvGetCurRecTime() >= 10 * 60)  // ѭ��¼��
            {
                dv_frm_ctrl->rec_status = 0;
                Cvr_DvHaltRecord();
                eLIBs_memset((void *)(&dv_frm_ctrl->cur_rec_time), 0, sizeof((dv_frm_ctrl->cur_rec_time)));
                // ��ʼ¼��
                Cvr_DvStartRecord();
                dv_frm_ctrl->rec_status = 1;

            }
        }
    }
    return EPDK_OK;

}



static __s32 __dv_frm_on_create(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

    __msg("__dv_frm_on_create\n");

    // ��ʼ��ˮӡͼ����Դ
    cvr_water_mark_res_init();

    dv_frm_ctrl->cur_state    = DV_ON_REC;
    dv_frm_ctrl->rec_status   = 0;
    dv_frm_ctrl->frmwin_hdl = msg->h_deswin ;
    dv_frm_ctrl->user_data = dsk_reg_get_para_by_app(REG_APP_DV);

    // ��DVģ��
    __dv_init(dv_frm_ctrl);
	
    // ����ʱ����ʾTIMER
    GUI_SetTimer(msg->h_deswin, TIMER_STATUS_ID, TIMER_STATUS_TIMEROUT_ID, NULL);
	
    GUI_SetTimer(msg->h_deswin, TIMER_DV_SRCH_ID, 35, NULL);
#ifdef	APP_DV_HBAR	
	GUI_SetTimer(msg->h_deswin,TIMER_DV_BATT_CHCK_ID, 1000, NULL);
#endif
    dv_frm_ctrl->os_timer_hdl = esKRNL_TmrCreate(500, OS_TMR_OPT_PRIO_HIGH | OS_TMR_OPT_PERIODIC, (OS_TMR_CALLBACK)__dv_timer_record_proc, (void *)dv_frm_ctrl);
    if(dv_frm_ctrl->os_timer_hdl)
    {
        esKRNL_TmrStart(dv_frm_ctrl->os_timer_hdl);
    }
    dv_frm_ctrl->delete_file_tsk = esKRNL_TCreate(__dv_delete_first_file_thread, dv_frm_ctrl, 0x2000, KRNL_priolevel3);
	next_signal_level = prev_signal_level = 0;
    return EPDK_OK;
}

static void dv_save_value(void)
{
	reg_dv_para_t * dv_para;
	__msg("dv_save_value, spi_auto_srch->max_channel = %d\n", spi_auto_srch->max_channel);
	dv_para = (reg_dv_para_t *)dsk_reg_get_para_by_app(REG_APP_DV);

	dv_para->channel = spi_auto_srch->max_channel;
}

static __s32 __dv_frm_on_destroy(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

    __msg("__dv_frm_on_destroy\n");	
	
    // �ж��Ƿ���¼���У�������ֹͣ��
    if(dv_frm_ctrl->rec_status != 0)
    {
        dv_frm_ctrl->rec_status = 0;
        // ֹͣ¼��
        Cvr_DvStopRecord();
    }
    if(dv_frm_ctrl->delete_file_tsk)
    {
        while(esKRNL_TDelReq(dv_frm_ctrl->delete_file_tsk) != OS_TASK_NOT_EXIST)
        {
            esKRNL_TimeDly(1);
        }
        dv_frm_ctrl->delete_file_tsk = NULL;
    }
    // ɾ���߳�
    if(dv_frm_ctrl->os_timer_hdl != NULL)
    {
        esKRNL_TmrStop(dv_frm_ctrl->os_timer_hdl, OS_TMR_OPT_PRIO_HIGH | OS_TMR_OPT_PERIODIC, dv_frm_ctrl);
        esKRNL_TmrDel(dv_frm_ctrl->os_timer_hdl);
        dv_frm_ctrl->os_timer_hdl = NULL;
    }
#ifdef	APP_DV_HBAR	
	if(dv_frm_ctrl->subset)
	{
//		DV_Uipara_Subset_UnInit();
//		esKRNL_TimeDly(10);
		GUI_LyrWinDelete(dv_frm_ctrl->subset);
		dv_frm_ctrl->subset = NULL;
	}
#endif

    GUI_KillTimer(msg->h_deswin, TIMER_STATUS_ID);
    if( GUI_IsTimerInstalled(msg->h_deswin, TIMER_DIALOAG_TIMEOUT_ID) )
        GUI_KillTimer(msg->h_deswin, TIMER_DIALOAG_TIMEOUT_ID);

    if( GUI_IsTimerInstalled(msg->h_deswin, TIMER_DV_SRCH_ID) )
	{
  		GUI_KillTimer(msg->h_deswin, TIMER_DV_SRCH_ID);
	}
	if( GUI_IsTimerInstalled(msg->h_deswin, TIMER_DV_SRCH_OVER_ID) )
	{
  		GUI_KillTimer(msg->h_deswin, TIMER_DV_SRCH_OVER_ID);
	}
	
	if( GUI_IsTimerInstalled(msg->h_deswin, TIMER_DV_BATT_CHCK_ID) )
	{
		GUI_KillTimer(msg->h_deswin, TIMER_DV_BATT_CHCK_ID);
	}
#ifdef	APP_DV_HBAR	
	if(dv_frm_ctrl->subset)
	{
		GUI_LyrWinDelete(dv_frm_ctrl->subset);
		dv_frm_ctrl->subset = NULL;
	}
#endif
    _dv_exit(dv_frm_ctrl);

    cvr_water_mark_res_uninit();
//	dsk_reg_flush();
//	esKRNL_TimeDly(10);
    esMEMS_Mfree(0, dv_frm_ctrl);
	
    return EPDK_OK;
}

static __s32 _dv_single_paint(void)
{
    __gui_msg_t *msg;

    if(dv_single_level == GUI_MASG_SINGLE0)
        msg->dwReserved = DV_PAINT_SINGLE0 ;
    else if(dv_single_level == GUI_MASG_SINGLE1)
        msg->dwReserved = DV_PAINT_SINGLE1 ;
    else if(dv_single_level == GUI_MASG_SINGLE2)
        msg->dwReserved = DV_PAINT_SINGLE2 ;
    else if(dv_single_level == GUI_MASG_SINGLE3)
        msg->dwReserved = DV_PAINT_SINGLE3 ;
    else
        msg->dwReserved = DV_PAINT_SINGLE4 ;

    __dv_frm_on_paint( msg);
}
static __s32 __dv_frm_on_paint(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

    if (GUI_LyrWinGetSta(GUI_WinGetLyrWin(msg->h_deswin)) == GUI_LYRWIN_STA_SUSPEND)
        return EPDK_FAIL;

    GUI_LyrWinSel(dv_frm_ctrl->frm_lyr_hdl);
    GUI_SetFont(dv_frm_ctrl->font);
    GUI_UC_SetEncodeUTF8();
    GUI_SetColor(TEXT_COLOR);

    if( DV_PAINT_FLASH_ICON1 == msg->dwReserved )
    {

        //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->rec_flash1_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if( DV_PAINT_FLASH_ICON2 == msg->dwReserved )
    {
        //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->rec_flash2_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if( DV_PAINT_MENUBAR_BG == msg->dwReserved )
    {
        //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->menu_bar_bg_handle), dv_frm_ctrl->uipara->menu_bar_bg_rect.x, dv_frm_ctrl->uipara->menu_bar_bg_rect.y);
        //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->mp_fcs_handle), dv_frm_ctrl->uipara->menu_bar_bg_rect.x, dv_frm_ctrl->uipara->menu_bar_bg_rect.y);
    }
    else if( DV_CLEAR_MENUBAR_BG == msg->dwReserved )
    {
        GUI_ClearRect(dv_frm_ctrl->uipara->menu_bar_bg_rect.x, dv_frm_ctrl->uipara->menu_bar_bg_rect.y, \
                      dv_frm_ctrl->uipara->menu_bar_bg_rect.x + dv_frm_ctrl->uipara->menu_bar_bg_rect.width - 1 , \
                      dv_frm_ctrl->uipara->menu_bar_bg_rect.y + dv_frm_ctrl->uipara->menu_bar_bg_rect.height - 1 );
    }
    else if(DV_PAINT_SINGLE0 == msg->dwReserved)
    {

        GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->single0_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if(DV_PAINT_SINGLE1 == msg->dwReserved)
    {

        GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->single1_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if(DV_PAINT_SINGLE2 == msg->dwReserved)
    {

        GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->single2_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if(DV_PAINT_SINGLE3 == msg->dwReserved)
    {

        GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->single3_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else if(DV_PAINT_SINGLE4 == msg->dwReserved)
    {

        GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->single4_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
    }
    else	// paint all
    {
        char str[64] ;
        //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->hbar_back_handle), dv_frm_ctrl->uipara->hbar_bg_rect.x, dv_frm_ctrl->uipara->hbar_bg_rect.y);

        //__msg("dv_frm_ctrl->uipara->hbar_back_handle = %x\n",dv_frm_ctrl->uipara->hbar_back_handle);
        //__msg("dv_frm_ctrl->uipara->hbar_bg_rect.x = %d\n",dv_frm_ctrl->uipara->hbar_bg_rect.x);
        //__msg("dv_frm_ctrl->uipara->hbar_bg_rect.y = %d\n",dv_frm_ctrl->uipara->hbar_bg_rect.y);

        if( DV_ON_REC == dv_frm_ctrl->cur_state )
        {
            //GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->work_rec_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);

            //__msg("dv_frm_ctrl->user_data->rec_quality = %d\n",dv_frm_ctrl->user_data->rec_quality);
            //__msg("dv_frm_ctrl->user_data->cam_quality = %d\n",dv_frm_ctrl->user_data->cam_quality);

            //__msg("dv_frm_ctrl->uipara->rec_quantity_strid[0] = %x\n",dv_frm_ctrl->uipara->rec_quantity_strid[0]);
            //__msg("dv_frm_ctrl->uipara->rec_quantity_strid[1] = %x\n",dv_frm_ctrl->uipara->rec_quantity_strid[1]);


            //dsk_langres_get_menu_text(dv_frm_ctrl->uipara->rec_quantity_strid[dv_frm_ctrl->user_data->rec_quality], str, GUI_TITLE_MAX);


            //__msg("dv_frm_ctrl->uipara->quantity_text_pos.x = %d\n",dv_frm_ctrl->uipara->quantity_text_pos.x);
            //__msg("dv_frm_ctrl->uipara->quantity_text_pos.y = %d\n",dv_frm_ctrl->uipara->quantity_text_pos.y);




            //GUI_DispStringAt(str,dv_frm_ctrl->uipara->quantity_text_pos.x, dv_frm_ctrl->uipara->quantity_text_pos.y );
        }
        else
        {
            //	GUI_BMP_Draw(dsk_theme_hdl2buf(dv_frm_ctrl->uipara->work_cam_handle), dv_frm_ctrl->uipara->work_mode_icon_pos.x, dv_frm_ctrl->uipara->work_mode_icon_pos.y);
            //	dsk_langres_get_menu_text(dv_frm_ctrl->uipara->image_quantity_strid [dv_frm_ctrl->user_data->cam_quality], str, GUI_TITLE_MAX);
            //GUI_DispStringAt(str,dv_frm_ctrl->uipara->quantity_text_pos.x, dv_frm_ctrl->uipara->quantity_text_pos.y );
        }
    }
    return EPDK_OK;
}

static __u32 dv_set_srch_signal_value(__u32 channel)
{
	ES_FILE *ktemp;
	__u32 channel_temp = channel;
	__u32 ret = 0;
//	__info("dv_set_srch_signal_value, channel = %d\n", channel);
	spi_auto_srch->max_channel = channel;
	ktemp = eLIBs_fopen("b:\\INPUT\\MATRIX_KEY", "w");
	if(!ktemp)
	{
	    __msg("open_key_fail\n");
		return EPDK_OK;
	}
	eLIBs_fioctrl(ktemp, DRV_KEY_CMD_AUTO_SEARCH_SPI, NULL, &channel_temp);
	esKRNL_TimeDly(35);
	eLIBs_fioctrl(ktemp, DRV_KEY_CMD_SET_FIRST_DEBOUNCE_TIME, NULL, &ret);
	eLIBs_fclose( ktemp );
//	__info("channel_temp = %d, ret = %d\n", channel_temp, ret);
	return ret;
}


static __s32 __dv_frm_on_key_proc(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

	//__msg("__dv_frm_on_key_proc\n");
	
	if(((msg->dwAddData1 == GUI_MSG_KEY_LONGLEFT)||(msg->dwAddData1 == GUI_MSG_KEY_LONGRIGHT))\
		&&(msg->dwAddData2 == KEY_UP_ACTION))
	{
		//eLIBs_memset(spi_auto_srch,0,sizeof(auto_search));
		if(RECORD_STOP != Cvr_DvGetRecState())		//¼������н�ֹ�Զ���̨
	    {
	    	return EPDK_OK;
		}
		
		spi_auto_srch->channel = 0;
		spi_auto_srch->max_value = 0;
		spi_auto_srch->max_channel = 0;
		spi_auto_srch->key_save_flg = 1;
		spi_auto_srch->save_cnt = 0;
		key_flag = KEY_PRESS_ACTION;

		return EPDK_OK;
	}
	
	if(msg->dwAddData1 == GUI_MSG_KEY_MENU)       // �������ò˵�
    {
		__mymsg("GUI_MSG_KEY_MENU key\n");
        if(msg->dwAddData2 == KEY_UP_ACTION)
        {
        	if(Cvr_DvGetWorkMode() == DV_ON_REC )
        	{
                if(RECORD_STOP == Cvr_DvGetRecState())
                {    
                    Dv_cmd2parent(msg->h_deswin, ID_OP_DV_TO_HOME, 0, 0);
                }
				else
				{
					__dv_on_stop_record(msg);
					esKRNL_TimeDly(5);
                    Dv_cmd2parent(msg->h_deswin, ID_OP_DV_TO_HOME, 0, 0);
				}
        	}
			else if(Cvr_DvGetWorkMode() == DV_ON_CAM )
			{
				Dv_cmd2parent(msg->h_deswin, ID_OP_DV_TO_HOME, 0, 0);
			}
        }

		return EPDK_OK;
    }
	if((msg->dwAddData1 == GUI_MSG_KEY_LEFT)&&(msg->dwAddData2 == KEY_UP_ACTION))
	{
		ES_FILE *ktemp;
		single_t key_value;
		
		ktemp = eLIBs_fopen("b:\\INPUT\\MATRIX_KEY", "w");
		if(!ktemp)
    	{
			return EPDK_OK;
    	}
		if(RECORD_STOP != Cvr_DvGetRecState())		//¼������н�ֹ��̨
	    {
	    	return EPDK_OK;
		}
		spi_auto_srch->key_save_flg = 1;
		spi_auto_srch->save_cnt = 0;
		spi_auto_srch->max_channel += 1;
		if((spi_auto_srch->max_channel > 31)||(spi_auto_srch->max_channel < 0))
		{
			spi_auto_srch->max_channel = 0;
		}
		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_AUTO_SEARCH_SPI, NULL, &spi_auto_srch->max_channel);
		esKRNL_TimeDly(35);
		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_SET_FIRST_DEBOUNCE_TIME, NULL, &key_value);
		eLIBs_fclose( ktemp );
#ifdef	APP_DV_HBAR
		__app_dv_draw_signal_level(dv_frm_ctrl->subset, key_value.single_value);
		__app_dv_draw_freq_hbar(dv_frm_ctrl->subset, channel_freq[spi_auto_srch->max_channel]);
#endif
		dv_save_value();
		return EPDK_OK;
	}
	else if((msg->dwAddData1 == GUI_MSG_KEY_RIGHT)&&(msg->dwAddData2 == KEY_UP_ACTION))
	{
		ES_FILE *ktemp;
		single_t key_value;
		
		ktemp = eLIBs_fopen("b:\\INPUT\\MATRIX_KEY", "w");
		if(!ktemp)
    	{
			return EPDK_OK;
    	}
		if(RECORD_STOP != Cvr_DvGetRecState())
	    {
	    	return EPDK_OK;
		}
		spi_auto_srch->key_save_flg = 1;
		spi_auto_srch->save_cnt = 0;
		spi_auto_srch->max_channel -= 1;
		if((spi_auto_srch->max_channel > 31)||(spi_auto_srch->max_channel < 0))
		{
			spi_auto_srch->max_channel = 31;
		}
		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_AUTO_SEARCH_SPI, NULL, &spi_auto_srch->max_channel);
		esKRNL_TimeDly(35);
		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_SET_FIRST_DEBOUNCE_TIME, NULL, &key_value);
		eLIBs_fclose( ktemp );
#ifdef	APP_DV_HBAR
		__app_dv_draw_signal_level(dv_frm_ctrl->subset, key_value.single_value);
		__app_dv_draw_freq_hbar(dv_frm_ctrl->subset, channel_freq[spi_auto_srch->max_channel]);
#endif
		dv_save_value();
		return EPDK_OK;
	}
	
	if(msg->dwAddData1 == GUI_MSG_KEY_SEETING)        // �л�ģʽ(��������ģʽ)
    {
        if(msg->dwAddData2 == KEY_UP_ACTION)
        {
        	if(dv_frm_ctrl->cur_state == DV_ON_REC )
        	{
	            if(RECORD_STOP == Cvr_DvGetRecState())
	            {
	                //__msg("Switch to photograph \n");
	                // �л�������״̬
	                Cvr_DvSetWorkMode(WORK_MODE_CAM);
	                dv_frm_ctrl->cur_state = DV_ON_CAM ;
	                //  UI ���ָ��µ���¼��ģʽ�л�������״̬
	                __dv_frm_on_paint( msg);
	            }
				else
				{
					__dv_on_stop_record(msg);
					esKRNL_TimeDly(5);
					Cvr_DvSetWorkMode(WORK_MODE_CAM);
	                dv_frm_ctrl->cur_state = DV_ON_CAM ;
	                //  UI ���ָ��µ���¼��ģʽ�л�������״̬
	                __dv_frm_on_paint( msg);
				}
        	}
			else if(dv_frm_ctrl->cur_state == DV_ON_CAM )
			{
                // �л���¼��Ԥ��״̬
                Cvr_DvSetWorkMode(WORK_MODE_REC);
                dv_frm_ctrl->cur_state = DV_ON_REC;
                // UI ���ָ��µ�������״̬�л���¼��ģʽ
                __dv_frm_on_paint( msg);
			}
			record_file_index=__dv_get_last_file(FILE_PATH);
        }
#ifdef	APP_DV_HBAR
		__app_dv_draw_rec_time_hbar(msg, 0);
		__app_dv_draw_mode_hbar(msg);
#endif
		spi_auto_srch->key_save_flg = 1;
		spi_auto_srch->save_cnt = 0;

		return EPDK_OK;
    }
	
    if(dv_frm_ctrl->cur_state == DV_ON_REC)
    {
#ifdef	APP_DV_HBAR
		__app_dv_draw_mode_hbar(msg);
#endif
        if(msg->dwAddData1 == GUI_MSG_KEY_ENTER)        // ¼��Ŀ�ʼ��ֹͣ
        {	
#if 1
            if(msg->dwAddData2 == KEY_UP_ACTION)
            {
                ES_DIR			*p_file;

                // ���̿ռ���
                p_file = eLIBs_opendir(USER_DISK);
                if(!p_file)
                {
                    RECT rect ;

                    rect.x = ( dv_frm_ctrl->uipara->scn_w - dv_frm_ctrl->uipara->msg_box_size.width ) >> 1 ;
                    rect.y = ( dv_frm_ctrl->uipara->scn_h - dv_frm_ctrl->uipara->msg_box_size.height ) >> 1 ;
                    rect.width  = dv_frm_ctrl->uipara->msg_box_size.width ;
                    rect.height = dv_frm_ctrl->uipara->msg_box_size.height ;

                    dv_dialog_creat(dv_frm_ctrl, &rect, dv_frm_ctrl->uipara->msg_box_bg , dv_frm_ctrl->uipara->no_sd_id);
                    return EPDK_OK;
                }
                // ��ʼ¼��
                if(RECORD_STOP == Cvr_DvGetRecState())
                {
                    __msg("To start recording \n");
                    __dv_on_start_record(msg);
                }
                // ֹͣ¼��
                else if(RECORD_START == Cvr_DvGetRecState())
                {
                    __msg("To stop recording \n");
                    __dv_on_stop_record(msg);
#ifdef APP_DV_HBAR					
					__app_dv_draw_rec_time_hbar(msg, 0);
#endif
                    __dv_frm_on_paint(msg);
                }
            }
#endif
        }
//        else if(msg->dwAddData1 == GUI_MSG_KEY_MENU)       // �������ò˵�
//        {

//            if(msg->dwAddData2 == KEY_UP_ACTION)
//            {
//            	__msg("Cvr_DvGetWorkMode():%d\n", Cvr_DvGetWorkMode());
//            	if(Cvr_DvGetWorkMode() == DV_ON_REC )
//            	{
//	                if(RECORD_STOP == Cvr_DvGetRecState())
//	                {
//	                	
//						__msg("RECORD_STOP: ID_OP_DV_TO_HOME\n");
//	                    Dv_cmd2parent(msg->h_deswin, ID_OP_DV_TO_HOME, 0, 0);

//	                }
//            	}
//				else if(Cvr_DvGetWorkMode() == DV_ON_CAM )
//				{
//					__msg("ID_OP_DV_TO_HOME\n");
//					Dv_cmd2parent(msg->h_deswin, ID_OP_DV_TO_HOME, 0, 0);
//				}
//            }
//        }
        return EPDK_OK;
    }
    else if(dv_frm_ctrl->cur_state == DV_ON_CAM)
    {
#ifdef	APP_DV_HBAR
		__app_dv_draw_mode_hbar(msg);
#endif    
        if(msg->dwAddData1 == GUI_MSG_KEY_ENTER)        // ��ʼ����
        {
            if(msg->dwAddData2 == KEY_UP_ACTION)
            {
                ES_DIR         *p_file;
                __u64			tmp_size ;

                // ���̿ռ���
                p_file = eLIBs_opendir(USER_DISK);
                if(!p_file)
                {
                    RECT rect ;
                    //  ����û��tf ���Ի���
                    rect.x = ( dv_frm_ctrl->uipara->scn_w - dv_frm_ctrl->uipara->msg_box_size.width ) >> 1 ;
                    rect.y = ( dv_frm_ctrl->uipara->scn_h - dv_frm_ctrl->uipara->msg_box_size.height ) >> 1 ;
                    rect.width = dv_frm_ctrl->uipara->msg_box_size.width ;
                    rect.height = dv_frm_ctrl->uipara->msg_box_size.height ;
                    dv_dialog_creat(dv_frm_ctrl, &rect, dv_frm_ctrl->uipara->msg_box_bg , dv_frm_ctrl->uipara->no_sd_id);

//                    __msg("there is no sd\n");

                    return EPDK_OK;
                }
                // ���̿ռ��������޷���������
                tmp_size = eLIBs_GetVolFSpace(USER_DISK) - DISK_FULL_LEVEL;
                if(tmp_size <= (long long)0)    // ֹͣ��ǰ¼�ƣ���ʾ���̿ռ���
                {
                    // need to do :�����������Ի���
                    RECT rect ;
                    rect.x = ( dv_frm_ctrl->uipara->scn_w - dv_frm_ctrl->uipara->msg_box_size.width ) >> 1 ;
                    rect.y = ( dv_frm_ctrl->uipara->scn_h - dv_frm_ctrl->uipara->msg_box_size.height ) >> 1 ;
                    rect.width = dv_frm_ctrl->uipara->msg_box_size.width ;
                    rect.height = dv_frm_ctrl->uipara->msg_box_size.height ;
                    dv_dialog_creat(dv_frm_ctrl, &rect, dv_frm_ctrl->uipara->msg_box_bg , dv_frm_ctrl->uipara->disk_full_id);
                    return EPDK_OK;
                }

                // ����ʱ��ˮӡ
                if(dv_frm_ctrl->user_data->water_mark_enable == 1)
                {
                    dv_frm_ctrl->water_mark_para.total = 19;
                    dv_frm_ctrl->water_mark_para.pos.x = 20;
                    dv_frm_ctrl->water_mark_para.pos.y = 20;
                    __dv_get_time_mark_index(dv_frm_ctrl->sys_date, dv_frm_ctrl->sys_time, dv_frm_ctrl->water_mark_para.IDlist, 0);
                    Cvr_DvShowOverlay(&dv_frm_ctrl->water_mark_para, 0);
                }
                // ��������, ��������������
#if 0
                if(EPDK_OK == keytone_set_path(VOICE_TAKE_IMG))
                {
                    keytone_play();
                }
#endif

                if( DISP_OUTPUT_TYPE_LCD == dsk_display_get_output_type())
                {
                    // ��ʼ����
#ifdef	APP_DV_HBAR
					__app_dv_draw_cam_play_pause(msg, 0);	
#endif
                    Cvr_DvTakeImage(1);
				
					
#ifdef	APP_DV_HBAR
					__app_dv_draw_cam_play_pause(msg, 1);	
#endif

                }
                else
                {
                    __wrn("only can take picture in lcd output mode ");
                }
                // ���ʱ��ˮӡ
                if(dv_frm_ctrl->user_data->water_mark_enable == 1)
                {
                    dv_frm_ctrl->water_mark_para.total = 0;
                    dv_frm_ctrl->water_mark_para.pos.x = 20;
                    dv_frm_ctrl->water_mark_para.pos.y = 20;

                    Cvr_DvShowOverlay(&dv_frm_ctrl->water_mark_para, 0);
                }
            }
        }
        return EPDK_OK;
    }

    return EPDK_OK;
}

extern __u32  channel_freq[32];
static __s32 __dv_frm_on_timer_proc(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;
    static __u8 flag = 0;
	//static __s32 save_cnt = 0;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

    if(msg->dwAddData1 == TIMER_STATUS_ID)    // ¼��ʱ�����µ�ǰ��¼��ʱ��;�ط�ʱ�����µ�ǰ����ʱ��ͽ���
    {
        // ¼��״̬���
        if(dv_frm_ctrl->rec_status != 0)
        {
            __dv_on_recording(msg);
			__mymsg("Cvr_DvGetCurRecTime() : %d\n", Cvr_DvGetCurRecTime());
#ifdef	APP_DV_HBAR			
			__app_dv_draw_rec_time_hbar(msg, Cvr_DvGetCurRecTime()*1000);
#endif
        }
		if((spi_auto_srch->save_cnt++ > 10)&&(spi_auto_srch->key_save_flg == 1))
		{	
			dsk_reg_flush();
			spi_auto_srch->save_cnt = 0;
			spi_auto_srch->key_save_flg = 0;
		}
    }
    else if(msg->dwAddData1 == TIMER_DIALOAG_TIMEOUT_ID)
    {
       	__here__;
        dv_dialog_destroy(dv_frm_ctrl);
    }
	else if((msg->dwAddData1 == TIMER_DV_SRCH_ID)&&(key_flag == KEY_PRESS_ACTION))
	{
		ES_FILE *ktemp;
		single_t key_value;
		
		//__msg("msg->dwAddData1 == TIMER_DV_SRCH_ID\n");
		ktemp = eLIBs_fopen("b:\\INPUT\\MATRIX_KEY", "w");
		if(!ktemp)
    	{
//	        __msg("open_key_fail\n");
			return EPDK_OK;
    	}
		
		if(KEY_PRESS_ACTION == key_flag)
		{
			if(spi_auto_srch->channel)
			{
				eLIBs_fioctrl(ktemp, DRV_KEY_CMD_SET_FIRST_DEBOUNCE_TIME, NULL, &key_value);
#ifdef	APP_DV_HBAR
				__app_dv_draw_signal_level(dv_frm_ctrl->subset, key_value.single_value);
#endif
				if(spi_auto_srch->max_value < key_value.single_value)
				{
					spi_auto_srch->max_value = key_value.single_value; 
					spi_auto_srch->max_channel = spi_auto_srch->channel - 1;
				}
			}
			eLIBs_fioctrl(ktemp, DRV_KEY_CMD_AUTO_SEARCH_SPI, NULL, &spi_auto_srch->channel);
#ifdef	APP_DV_HBAR	
			__app_dv_draw_freq_hbar(dv_frm_ctrl->subset, channel_freq[spi_auto_srch->channel]);			
#endif
		}
		eLIBs_fclose( ktemp );
		if(++spi_auto_srch->channel >31)
		{
			spi_auto_srch->search_end = 1;
			spi_auto_srch->channel = 0;
			key_flag = KEY_NONE_ACTION;
			if(GUI_IsTimerInstalled(msg->h_deswin, TIMER_DV_SRCH_OVER_ID))
	        {
	            GUI_ResetTimer(msg->h_deswin,TIMER_DV_SRCH_OVER_ID,35,NULL);
	        }
			else
			{
				GUI_SetTimer(msg->h_deswin, TIMER_DV_SRCH_OVER_ID, 35, NULL);
			}
		}
					
    }
	else if((LOWORD(msg->dwAddData1) == TIMER_DV_SRCH_OVER_ID)&&(spi_auto_srch->search_end))
	{
		ES_FILE *ktemp;
		single_t key_value;
		
		ktemp = eLIBs_fopen("b:\\INPUT\\MATRIX_KEY", "w");
		if(!ktemp)
    	{
//	        __msg("open_key_fail\n");
			return EPDK_OK;
    	}
		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_SET_FIRST_DEBOUNCE_TIME, NULL, &key_value);
		if(spi_auto_srch->max_value < key_value.single_value)
		{
			spi_auto_srch->max_value = key_value.single_value; 
			spi_auto_srch->max_channel = 31;
		}
#ifdef	APP_DV_HBAR
		__app_dv_draw_signal_level(dv_frm_ctrl->subset, spi_auto_srch->max_value);
#endif

		eLIBs_fioctrl(ktemp, DRV_KEY_CMD_AUTO_SEARCH_SPI, NULL, &spi_auto_srch->max_channel);
#ifdef	APP_DV_HBAR	
		__app_dv_draw_freq_hbar(dv_frm_ctrl->subset, channel_freq[spi_auto_srch->max_channel]);			
#endif
		dv_save_value();
		spi_auto_srch->search_end = 0;
		eLIBs_fclose( ktemp );
		
		if( GUI_IsTimerInstalled(msg->h_deswin, TIMER_DV_SRCH_OVER_ID) )
		{
			GUI_KillTimer(msg->h_deswin, TIMER_DV_SRCH_OVER_ID);
		}
	}
#ifdef	APP_DV_HBAR
	else if(LOWORD(msg->dwAddData1) == TIMER_DV_BATT_CHCK_ID)
	{
		__app_dv_draw_rec_batt_status(dv_frm_ctrl->subset);
	}
#endif
    return EPDK_OK;
}

static __s32 __dv_frm_set_record_quality_proc(__gui_msg_t *msg)
{
    dv_frmwin_para_t        	*dv_frm_ctrl;

    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

    if( dv_frm_ctrl->cur_state == DV_ON_REC_SET)
    {
        switch(msg->dwAddData1)
        {
        case 0:
            dv_frm_ctrl->user_data->rec_quality = 0;
            Cvr_DvSetRecQuality(RECORD_QUALITY_640_480);
            break ;
        case 1:
            dv_frm_ctrl->user_data->rec_quality = 1;
            Cvr_DvSetRecQuality(RECORD_QUALITY_1280_720);
            break ;
        }
    }
    else if( dv_frm_ctrl->cur_state == DV_ON_CAM_SET)
    {
        switch(msg->dwAddData1)
        {
        case 0:
            dv_frm_ctrl->user_data->cam_quality = 0;
            Cvr_DvSetRecQuality(CAMERA_QUALITY_100);
            break ;
        case 1:
            dv_frm_ctrl->user_data->cam_quality = 1;
            Cvr_DvSetRecQuality(CAMERA_QUALITY_200);
            break ;
        case 2:
            dv_frm_ctrl->user_data->cam_quality = 2;
            Cvr_DvSetRecQuality(CAMERA_QUALITY_300);
            break ;
        }
    }
    // updata quality setting
    __dv_frm_on_paint(msg);
    return EPDK_OK;
}

#ifdef	APP_DV_HBAR
__u32  channel_freq[32]=
{
   //0x0000,
   //chanl    A
   5740,				   //  1			   5740
   5760,				   //  2			   5760
   5780,				   //  3			   5780
   5800,				   //  4			   5800
   5820,				   //  5			   5820
   5840,				   //  6			   5840
   5860,				   //  7			   5860
   5880,				   //  8			   5880

   //chanl   B
   5733,				   //   9			   5733
   5752,				   //  10			   5752
   5771,				   //  11			   5771
   5790,				   //  12			   5790
   5809,				   //  13			   5809
   5828,				   //  14			   5828
   5847,				   //  15			   5847
   5866,				   //  16			   5866
   
   //chanl	 C
   5705,				   //  17			   5705
   5685,				   //  18			   5685 
   5665,				   //  19			   5665
   5645,				   //  20			   5645
   5885,				   //  21			   5885
   5905,				   //  22			   5905
   5925,				   //  23			   5925
   5945,				   //  24			   5945

   //chanl	 D
   5865,				   // 25				5865
   5845,				   // 26			    5845
   5825,				   // 27			    5825
   5805,				   // 28			    5805
   5785,				   // 29			    5785
   5765,				   // 30			    5765
   5745,				   // 31			    5745
   5725,				   // 32 				5725

};

static H_LYR dv_32bpp_layer_create(RECT *rect, __s32 pipe)
{
	H_LYR layer = NULL;
	FB	fb =
	{
		{0, 0}, 										/* size 	 */
		{0, 0, 0},										/* buffer	 */
		{FB_TYPE_RGB, {PIXEL_COLOR_ARGB8888, 0, (__rgb_seq_t)0}},	 /* fmt 	  */
	};
	__disp_layer_para_t lstlyr =
	{
		DISP_LAYER_WORK_MODE_NORMAL,					/* mode 	 */
		0,												/* ck_mode	 */
		0,												/* alpha_en  */
		0,												/* alpha_val */
		1,												/* pipe 	 */
		0xff,											/* prio 	 */
		{0, 0, 0, 0},									/* screen	 */
		{0, 0, 0, 0},									/* source	 */
		DISP_LAYER_OUTPUT_CHN_DE_CH1,					/* channel	 */
		NULL											/* fb		 */
	};
	__layerwincreate_para_t lyrcreate_info =
	{
		"subset menu layer",
		NULL,
		GUI_LYRWIN_STA_SUSPEND,
		GUI_LYRWIN_NORMAL
	};
	fb.size.width		= rect->width;
	fb.size.height		= rect->height;
	lstlyr.src_win.x		= 0;
	lstlyr.src_win.y		= 0;
	lstlyr.src_win.width	= rect->width;
	lstlyr.src_win.height	= rect->height;
	lstlyr.scn_win.x		= rect->x;
	lstlyr.scn_win.y		= rect->y;
	lstlyr.scn_win.width	= rect->width;
	lstlyr.scn_win.height	= rect->height;
	lstlyr.pipe = pipe;
	lstlyr.fb = &fb;
	lyrcreate_info.lyrpara = &lstlyr;
	layer = GUI_LyrWinCreate(&lyrcreate_info);
	if( !layer )
	{
		__err("GUI_LyrWinCreate fail !\n");
	}
	return layer;
}

static __s32 power_level_2_display(power_level_e level)
{
    int ret = 0;

    switch(level)
    {
    case DSK_POWER_LEVEL_0:
        ret = 0;
        break;
    case DSK_POWER_LEVEL_1:
        ret = 1;
        break;
    case DSK_POWER_LEVEL_2:
        ret = 2;
        break;
    case DSK_POWER_LEVEL_3:
        ret = 3;
        break;
    case DSK_POWER_LEVEL_4:
        ret = 4;
        break;

    case DSK_POWER_LEVEL_5:
        ret = 5;
        break;

    default:
        ret = 0;
        break;
    }

    return ret;
}

static __u32 dv_signal_level_handle(__u32 level)
{
	__u32	ret = 0;
	switch(level/100)
	{
		case DV_LEVEL_NOSIGNAL:
			ret = DV_LEVEL_NOSIGNAL;
			break;
		case DV_LEVEL_SIGNAL_1:
			ret = DV_LEVEL_SIGNAL_1;
			break;
		case DV_LEVEL_SIGNAL_2:
			ret = DV_LEVEL_SIGNAL_2;
			break;
		case DV_LEVEL_SIGNAL_3:
			ret = DV_LEVEL_SIGNAL_3;
			break;
		case DV_LEVEL_SIGNAL_4:
			ret = DV_LEVEL_SIGNAL_4;
			break;
		case DV_LEVEL_SIGNAL_5:
		default:
			ret = DV_LEVEL_SIGNAL_5;
			break;
	}
	return ret;
}

static __s32 __app_dv_draw_signal_level(H_LYR hlyr, __u32 level)
{
	GUI_RECT gui_rect;
	dv_sub_res dv_subse_ui;

	if(NULL == hlyr)
	{
		__err("invalid para\n");
		return EPDK_FAIL;
	}
	
    dv_subse_ui = dv_get_sub_res();
	
	gui_rect.x0 = 400;
	gui_rect.y0 = 0;
	gui_rect.x1 = 460;
	gui_rect.y1 = 20;

	next_signal_level = dv_signal_level_handle(level);
	eLIBs_printf("level = %d, signal_level = %d\n",level, next_signal_level);
	if(next_signal_level == prev_signal_level)
	{
		return EPDK_OK;
	}
	GUI_LyrWinSel(hlyr);
	GUI_SetBkColor(0);
	GUI_ClearRectEx(&gui_rect);
	GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);

	if((next_signal_level == 1) || (next_signal_level == 2))
	{
		next_signal_level = 3;
	}
	GUI_BMP_RES_Draw(dv_subse_ui->bmp_subset_singal[next_signal_level], gui_rect.x0+20, gui_rect.y0+5);
	
	prev_signal_level = next_signal_level;
	return EPDK_OK;
}


static __s32 __app_dv_draw_rec_batt_status(H_LYR hlyr)
{
	power_level_e level;
	GUI_RECT gui_rect;
	dv_headbar_data_t dv_batt_ctrl;
	dv_sub_res  dv_subse_ui;

	if(NULL == hlyr)
	{
		__err("invalid para\n");
		return EPDK_FAIL;
	}
	
    dv_subse_ui = dv_get_sub_res();
	
	gui_rect.x0 = 320;
    gui_rect.y0 = 0;
    gui_rect.x1 = 400;
    gui_rect.y1 = 20;
	
	dsk_power_get_voltage_level(&level);
	dv_batt_ctrl.vol_level = power_level_2_display(level);  	//��������
	dv_batt_ctrl.charge_sta = dsk_get_charge_state();

	__msg("dv_batt_ctrl.vol_level:%d\n", dv_batt_ctrl.vol_level);
	GUI_LyrWinSel(hlyr);
	GUI_SetBkColor(0);
	GUI_ClearRectEx(&gui_rect);
	GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);
//	if(EPDK_TRUE == dv_batt_ctrl.charge_sta)
//    {
//		GUI_BMP_RES_Draw(dv_subse_ui->sub_dv_res->bmp_subset_charge[dv_batt_ctrl.vol_level], gui_rect.x0+20, gui_rect.y0+5);
//    }
//    else
//    {    	
		GUI_BMP_RES_Draw(dv_subse_ui->bmp_subset_vol[dv_batt_ctrl.vol_level], gui_rect.x0+20, gui_rect.y0+5);
//    }
	
	return EPDK_OK;
}

static __s32 __app_dv_draw_cam_play_pause(__gui_msg_t *msg, __s32 flag)
{
	GUI_RECT gui_rect;
	dv_frmwin_para_t        	*dv_frm_ctrl;
	dv_sub_res  dv_subse_ui;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
	
	if(NULL == dv_frm_ctrl->subset)
	{
		__err("invalid para\n");
		return EPDK_FAIL;
	}
	
	if(Cvr_DvGetWorkMode() == WORK_MODE_REC)
	{
		__msg("WORK_MODE_CAM\n");
		return EPDK_OK;
	}
	
	dv_subse_ui = dv_get_sub_res();
	
	gui_rect.x0 = 220;
    gui_rect.y0 = 0;
    gui_rect.x1 = 300;
    gui_rect.y1 = 50;

	GUI_LyrWinSel(dv_frm_ctrl->subset);
	GUI_SetBkColor(0);
	GUI_ClearRectEx(&gui_rect);
	GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);

	if(Cvr_DvGetWorkMode() == WORK_MODE_CAM)
	{
		GUI_BMP_RES_Draw(dv_subse_ui->cam_play_pause[flag], gui_rect.x0+20, gui_rect.y0+5);
	}
	else
	{
		return EPDK_OK;
		//GUI_DispStringInRect(time_text, &gui_rect, GUI_TA_VCENTER|GUI_TA_HCENTER);
	}
}

static __s32 __app_dv_draw_rec_time_hbar(__gui_msg_t *msg, __u32 time)
{
	char time_text[32];
	GUI_RECT gui_rect;
	dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
	
	__mymsg("__app_dv_draw_rec_time_hbar\n");
	if(NULL == dv_frm_ctrl->subset)
	{
		__err("invalid para\n");
		return EPDK_FAIL;
	}
	
	gui_rect.x0 = 220;
    gui_rect.y0 = 0;
    gui_rect.x1 = 300;
    gui_rect.y1 = 20;
	
	eLIBs_memset(time_text, 0 ,sizeof(time_text));	
	
	time2str_by_format_hour_show(time, time_text, TIME_AUTO_HMS);
	GUI_LyrWinSel(dv_frm_ctrl->subset);
	GUI_SetBkColor(0);
	GUI_ClearRectEx(&gui_rect);
	GUI_SetFont(SWFFont);
	GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);
	GUI_SetColor(GUI_RED);
	GUI_UC_SetEncodeUTF8();
	if(Cvr_DvGetWorkMode() == WORK_MODE_CAM)
	{
		__msg("WORK_MODE_CAM\n");
		return EPDK_OK;
		GUI_DispStringInRect(NULL, &gui_rect, GUI_TA_VCENTER|GUI_TA_HCENTER);
	}
	else
	{
		GUI_DispStringInRect(time_text, &gui_rect, GUI_TA_VCENTER|GUI_TA_HCENTER);
	}

	return EPDK_OK;
}


static __s32 __app_dv_draw_freq_hbar(H_LYR hlyr, __u32 channel)
{
	char text[6] = {0};
	GUI_RECT gui_rect;
	
	//__msg("__app_dv_draw_hbar\n");
	if(NULL == hlyr)
	{
		__err("invalid para\n");
		return EPDK_FAIL;
	}

	gui_rect.x0 = 0;
    gui_rect.y0 = 0;
    gui_rect.x1 = 120;
    gui_rect.y1 = 20;
	
	//dsk_langres_get_menu_text(STRING_REC, text, sizeof(text));

	text[0] = channel/1000 + '0';
	channel %= 1000;
	text[1] = '.';
	text[2] = channel /100 + '0';
	channel %= 100;
	text[3] = channel/10 + '0';
	channel %= 10;
	text[4] = channel + '0';
	text[5] = 'G';

	//__msg("text: %s\n", text);
	GUI_LyrWinSel(hlyr);
	GUI_SetBkColor(0);
	GUI_ClearRectEx(&gui_rect);
	GUI_SetFont(SWFFont);
	GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);
	GUI_SetColor(GUI_RED);
	GUI_UC_SetEncodeUTF8();
	GUI_DispStringInRect(text, &gui_rect, GUI_TA_VCENTER|GUI_TA_HCENTER);

	return EPDK_OK;
}

static __s32 __app_dv_draw_mode_hbar(__gui_msg_t *msg)
{
    char text[128];
	GUI_RECT gui_rect;
	dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
	
    //__msg("__app_dv_draw_hbar\n");
    if(NULL == dv_frm_ctrl->subset)
    {
        __err("invalid para\n");
        return EPDK_FAIL;
    }
	
	gui_rect.x0 = 120;
    gui_rect.y0 = 0;
    gui_rect.x1 = 220;
    gui_rect.y1 = 20;

	if(dv_frm_ctrl->cur_state == DV_ON_REC)
	{
		dsk_langres_get_menu_text(STRING_REC, text, sizeof(text));
	}
	else if(dv_frm_ctrl->cur_state == DV_ON_CAM)
	{
		dsk_langres_get_menu_text(STRING_CAM, text, sizeof(text));
	}
	//__msg("text: %s\n", text);
    GUI_LyrWinSel(dv_frm_ctrl->subset);
    GUI_SetBkColor(0);
    GUI_ClearRectEx(&gui_rect);
    GUI_SetFont(SWFFont);
    GUI_SetDrawMode(GUI_DRAWMODE_NORMAL);
    GUI_SetColor(GUI_RED);
    GUI_UC_SetEncodeUTF8();
    GUI_DispStringInRect(text, &gui_rect, GUI_TA_VCENTER|GUI_TA_HCENTER);
    return EPDK_OK;
}


void app_dv_subscene_create(__gui_msg_t *msg)
{
	__s32 width;
    __s32 height;
	RECT rect;
	__u32 channel;
	__u32 temp;
	reg_dv_para_t * dv_para;
	
	dv_frmwin_para_t        	*dv_frm_ctrl;
    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
	
	dsk_display_get_size(&width, &height);

	rect.x = 0;
    rect.y = 0;
    rect.width = width;
    rect.height = 60;

	dv_frm_ctrl->subset = dv_32bpp_layer_create(&rect, 1);
	if(NULL == dv_frm_ctrl->subset)
    {
    	__err("create dv_32bpp_layer failed\n");
        return; //EPDK_FAIL;
    }

	if(dsk_reg_get_app_restore_flag(REG_APP_DV))
    {
        __msg("load default dv...\n");
        dv_para = (reg_dv_para_t *)dsk_reg_get_default_para_by_app(REG_APP_DV);
    }
    else
    {
        __msg("load current dv...\n");
        dv_para = (reg_dv_para_t *)dsk_reg_get_para_by_app(REG_APP_DV);
    }
	if(dv_para)
    {
        channel = channel_freq[dv_para->channel];
        __msg("dv_para->channel = %d\n", channel);
    }
    else
    {
        channel = channel_freq[0];
    }
	
	temp = dv_set_srch_signal_value(dv_para->channel);
	GUI_LyrWinSetSta(dv_frm_ctrl->subset, GUI_LYR_STA_ON);
    GUI_LyrWinSetTop(dv_frm_ctrl->subset);
	__app_dv_draw_mode_hbar(msg);
	__app_dv_draw_freq_hbar(dv_frm_ctrl->subset, channel);
	__app_dv_draw_rec_time_hbar(msg, 0);
	__app_dv_draw_rec_batt_status(dv_frm_ctrl->subset);
	__app_dv_draw_signal_level(dv_frm_ctrl->subset, temp);
}
#endif


static __s32 __dv_frm_main_proc(__gui_msg_t *msg)
{
    switch(msg->id)
    {
    case GUI_MSG_CREATE:
    {
        //__here__;
        //__msg("GUI_MSG_CREATE, dv_frm_main_proc\n");
        __dv_frm_on_create(msg);
#ifdef	APP_DV_HBAR
		app_dv_subscene_create(msg);
#endif
    }
    break;
    case GUI_MSG_DESTROY:
    {	
        __dv_frm_on_destroy(msg);
    }
    break;
    case GUI_MSG_PAINT:
    {
        __dv_frm_on_paint(msg);
    }
    break;

    case GUI_MSG_KEY:
    {
        //__msg("gui_msg_key, msg->dwAddData1 = 0x%0x\n", msg->dwAddData1);
        __dv_frm_on_key_proc(msg);
    }
    break;
    case GUI_MSG_COMMAND:
    {
//        __msg("gui_msg_command\n");
    }
    break;
    case GUI_MSG_TIMER:
    {
        __dv_frm_on_timer_proc(msg);
    }
    break;

    case DSK_MSG_TVDAC_PLUGIN:		// tvdac plug in
    {
        dv_frmwin_para_t        	*dv_frm_ctrl;
        dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
//        __msg("TVDAC plug in \n");

#if (CVR_TVOUT_ENABLE == 1)
        __dv_tv_plugin(dv_frm_ctrl);
#endif
    }
    break;
    case DSK_MSG_TVDAC_PLUGOUT:		// tvdac plug out
    {
        dv_frmwin_para_t        	*dv_frm_ctrl;
        dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

//        __msg("TVDAC plug out \n");
#if (CVR_TVOUT_ENABLE == 1)
        __dv_tv_plugout(dv_frm_ctrl);
#endif
    }
    break;
    case DSK_MSG_HDMI_PLUGIN:		// hdmi plug in
    {
        dv_frmwin_para_t        	*dv_frm_ctrl;
        dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);

//        __msg("HDMI plug in \n");
#if (CVR_HDMI_ENABLE == 1)
        __dv_hdmi_plugin(dv_frm_ctrl);
#endif
    }
    break;
    case DSK_MSG_HDMI_PLUGOUT:		// hdmi plug out
    {
        dv_frmwin_para_t        	*dv_frm_ctrl;
        dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(msg->h_deswin);
//        __msg("HDMI plug out \n");
#if (CVR_HDMI_ENABLE == 1)
        __dv_hdmi_plugout(dv_frm_ctrl);
#endif
    }
    break;
    case DSK_MSG_FS_PART_PLUGIN:	// �ļ�ϵͳ��������
	{		
		
//	    __msg("File system plug in \n");
		record_file_index=__dv_get_last_file(FILE_PATH);
//		__msg("record_file_index = %d\n", record_file_index);
    	break;
	}
    case DSK_MSG_FS_PART_PLUGOUT:	// �ļ�ϵͳ�����γ�
    {
//        __msg("File system plug out \n");
        // ֹͣ��ǰ¼��
        if(RECORD_START == Cvr_DvGetRecState())
		{
			__dv_on_stop_record(msg);
		}
    }
    break;
    case CMD_DV_FRM_SET_RECORD_RESOLUTION:
    {

        __dv_frm_set_record_quality_proc(msg);
    }
    break ;
    case CMD_DV_FRM_SETTING_MENU_EXIT:
    {

        __dv_frm_set_record_quality_proc(msg);
    }
    break ;


    default:
        break;
    }
    return GUI_FrmWinDefaultProc(msg);
}



__s32 dv_frm_create(dv_frmwin_para_t *para)
{
    RECT rect ;
    __gui_framewincreate_para_t framewin_para;
    dv_frmwin_para_t *dv_frmwin_ctrl ;

    __msg("dv_frm_create\n");

    dv_frmwin_ctrl = (dv_frmwin_para_t *)esMEMS_Malloc(0, sizeof(dv_frmwin_para_t));
    if(dv_frmwin_ctrl == NULL)
    {
        __wrn("malloc error \n");
        return EPDK_FAIL;
    }
    eLIBs_memcpy(dv_frmwin_ctrl, para, sizeof(dv_frmwin_para_t));

    dv_frmwin_ctrl->uipara = Dv_GetUipara();
    rect.x = 0 ;
    rect.y = 0 ;
    rect.width = dv_frmwin_ctrl->uipara->scn_w ;
    rect.height = dv_frmwin_ctrl->uipara->scn_h ;
    dv_prevsingle_level = 0xff;
    dv_single_level = 0;

    dv_frmwin_ctrl->frm_lyr_hdl = dv_layer_create(&rect, DISP_LAYER_WORK_MODE_NORMAL);
    GUI_LyrWinSetSta(dv_frmwin_ctrl->frm_lyr_hdl, GUI_LYRWIN_STA_ON);
	
    eLIBs_memset(&framewin_para, 0, sizeof(__gui_framewincreate_para_t));
	
    framewin_para.name =	"dv frame win",
                  framewin_para.dwExStyle = WS_EX_NONE;
    framewin_para.dwStyle = WS_NONE | WS_VISIBLE;
    framewin_para.spCaption =  NULL;
    framewin_para.hOwner	= NULL;
    framewin_para.id         = DV_FRM_WIN_ID;
    framewin_para.hHosting = para->h_parent;
    framewin_para.FrameWinProc = (__pGUI_WIN_CB)esKRNL_GetCallBack((__pCBK_t)__dv_frm_main_proc);
    framewin_para.rect.x = 0;
    framewin_para.rect.y = 0;
    framewin_para.rect.width = rect.width;
    framewin_para.rect.height = rect.height;
    framewin_para.BkColor.alpha =  0;
    framewin_para.BkColor.red = 0;
    framewin_para.BkColor.green = 0;
    framewin_para.BkColor.blue = 0;
    framewin_para.attr =  (void *)dv_frmwin_ctrl;
    framewin_para.hLayer = dv_frmwin_ctrl->frm_lyr_hdl;

    return(GUI_FrmWinCreate(&framewin_para));

}

__s32 dv_frm_destroy( H_WIN h_win )
{
    dv_frmwin_para_t        	*dv_frm_ctrl;

    __msg("dv_frm_destroy\n");

    dv_frm_ctrl = (dv_frmwin_para_t *)GUI_WinGetAttr(h_win);
    // for frame win ,there is no need to call  GUI_FrmWinDelete to destroy frame win ,because the function of  GUI_LyrWinDelete will do that
    GUI_LyrWinDelete(dv_frm_ctrl->frm_lyr_hdl);
}



