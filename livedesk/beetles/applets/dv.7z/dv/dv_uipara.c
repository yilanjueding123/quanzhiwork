/*
*********************************************************************************************************
*											        ePDK
*						            the Easy Portable/Player Develop Kits
*									           home app sample
*
*						        	(c) Copyright 2006-2009, China
*											 All Rights Reserved
*
* File    : dv_uipara.c
* By      : lincoln
* Version : V1.00
*********************************************************************************************************
*/
#include "dv_i.h"
#include "dv_uipara.h"

#if  0
#define __msg(...)    		(eLIBs_printf("MSG:L%d(%s):", __LINE__, __FILE__),                 \
						     eLIBs_printf(__VA_ARGS__)									        )
#else
#define __msg(...)   
#endif


static dv_uipara_para_t dv_para ;

void Dv_Uipara_Init( void )
{
    ES_FILE *pfile ;
	__s32 i;

    pfile = eLIBs_fopen("b:\\DISP\\DISPLAY", "r+");
    if( !pfile )
    {
        __err("open display fail..........\n");
    }
    dv_para.scn_w = eLIBs_fioctrl( pfile, DISP_CMD_SCN_GET_WIDTH, 0, 0 );
    dv_para.scn_h = eLIBs_fioctrl( pfile, DISP_CMD_SCN_GET_HEIGHT, 0, 0 );
    eLIBs_fclose(pfile);
    //__log("dv_para.scn_w=%d,dv_para.scn_h=%d\n", dv_para.scn_w, dv_para.scn_h);

    dv_para.rec_setting_item_num = 2 ;
    dv_para.image_setting_item_num = 3;

    dv_para.work_mode_icon_pos.x = 2;//450;//10 ;
    dv_para.work_mode_icon_pos.y = 2; // 2;//0 ;

    dv_para.quantity_text_pos.x = 35 ;
    dv_para.quantity_text_pos.y = 2 ;

    dv_para.single0_handle = dsk_theme_open(ID_DV_RF_SIGNAL_0_BMP);
    dv_para.single1_handle = dsk_theme_open(ID_DV_RF_SIGNAL_1_BMP);
    dv_para.single2_handle = dsk_theme_open(ID_DV_RF_SIGNAL_2_BMP);
    dv_para.single3_handle = dsk_theme_open(ID_DV_RF_SIGNAL_3_BMP);
    dv_para.single4_handle = dsk_theme_open(ID_DV_RF_SIGNAL_FULL_BMP);

    dv_para.msg_box_bg = dsk_theme_open(ID_DV_MSG_BACK_BMP);
    dv_para.msg_box_size.width = 220 ;
    dv_para.msg_box_size.height = 120 ;

    dv_para.no_sd_id = STRING_NO_SD ;
    dv_para.disk_full_id = STRING_DISK_FULL ;

    dv_para.rec_quantity_strid[0] = STRING_REC_MP1 ;
    dv_para.rec_quantity_strid[1] = STRING_REC_MP1 ;
    dv_para.image_quantity_strid[0] = STRING_CAM_MP1;
    dv_para.image_quantity_strid[1] = STRING_CAM_MP2 ;
    dv_para.image_quantity_strid[2] = STRING_CAM_MP3;

//	create_bmp_res(ID_DV_SIGNAL_LEVEL_NONE_BMP, dv_para.sub_dv_res->bmp_subset_singal[0]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_ONE_BMP, dv_para.sub_dv_res->bmp_subset_singal[1]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_TWO_BMP, dv_para.sub_dv_res->bmp_subset_singal[2]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_THREE_BMP, dv_para.sub_dv_res->bmp_subset_singal[3]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_FOUR_BMP, dv_para.sub_dv_res->bmp_subset_singal[4]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_FIVE_BMP, dv_para.sub_dv_res->bmp_subset_singal[5]);
	
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_0_BMP, dv_para.sub_dv_res->bmp_subset_charge[0]);
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_1_BMP, dv_para.sub_dv_res->bmp_subset_charge[1]);
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_2_BMP, dv_para.sub_dv_res->bmp_subset_charge[2]);
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_3_BMP, dv_para.sub_dv_res->bmp_subset_charge[3]);
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_4_BMP, dv_para.sub_dv_res->bmp_subset_charge[4]);
//    create_bmp_res(ID_INIT_CHARGE_ENERGY_5_BMP, dv_para.sub_dv_res->bmp_subset_charge[5]);
	
//    create_bmp_res(ID_INIT_ENERGY_0_BMP, dv_para.sub_dv_res->bmp_subset_vol[0]);
//    create_bmp_res(ID_INIT_ENERGY_1_BMP, dv_para.sub_dv_res->bmp_subset_vol[1]);
//    create_bmp_res(ID_INIT_ENERGY_2_BMP, dv_para.sub_dv_res->bmp_subset_vol[2]);
//    create_bmp_res(ID_INIT_ENERGY_3_BMP, dv_para.sub_dv_res->bmp_subset_vol[3]);
//    create_bmp_res(ID_INIT_ENERGY_4_BMP, dv_para.sub_dv_res->bmp_subset_vol[4]);
//    create_bmp_res(ID_INIT_ENERGY_5_BMP, dv_para.sub_dv_res->bmp_subset_vol[5]);

//	create_bmp_res(ID_DV_TOP_CAM_BMP, dv_para.sub_dv_res->cam_play_pause[0]);
//	create_bmp_res(ID_DV_TOP1_CAM_BMP, dv_para.sub_dv_res->cam_play_pause[1]);
	
}
//void DV_Uipara_Subset_Init(void)
//{
//	
//	create_bmp_res(ID_DV_SIGNAL_LEVEL_NONE_BMP, dv_para.sub_dv_res->bmp_subset_singal[0]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_ONE_BMP, dv_para.sub_dv_res->bmp_subset_singal[1]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_TWO_BMP, dv_para.sub_dv_res->bmp_subset_singal[2]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_THREE_BMP, dv_para.sub_dv_res->bmp_subset_singal[3]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_FOUR_BMP, dv_para.sub_dv_res->bmp_subset_singal[4]);
//    create_bmp_res(ID_DV_SIGNAL_LEVEL_FIVE_BMP, dv_para.sub_dv_res->bmp_subset_singal[5]);

//	
//    create_bmp_res(ID_INIT_ENERGY_0_BMP, dv_para.sub_dv_res->bmp_subset_vol[0]);
//    create_bmp_res(ID_INIT_ENERGY_1_BMP, dv_para.sub_dv_res->bmp_subset_vol[1]);
//    create_bmp_res(ID_INIT_ENERGY_2_BMP, dv_para.sub_dv_res->bmp_subset_vol[2]);
//    create_bmp_res(ID_INIT_ENERGY_3_BMP, dv_para.sub_dv_res->bmp_subset_vol[3]);
//    create_bmp_res(ID_INIT_ENERGY_4_BMP, dv_para.sub_dv_res->bmp_subset_vol[4]);
//    create_bmp_res(ID_INIT_ENERGY_5_BMP, dv_para.sub_dv_res->bmp_subset_vol[5]);

//	create_bmp_res(ID_DV_TOP_CAM_BMP, dv_para.sub_dv_res->cam_play_pause[0]);
//	create_bmp_res(ID_DV_TOP1_CAM_BMP, dv_para.sub_dv_res->cam_play_pause[1]);
//}

//void DV_Uipara_Subset_UnInit(void)
//{
//		__msg("DV_Uipara_Subset_UnInit begin\n");
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[0]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[1]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[2]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[3]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[4]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_singal[5]);
		
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[0]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[1]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[2]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[3]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[4]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_charge[5]);
		
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[0]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[1]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[2]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[3]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[4]);
//		destroy_bmp_res(dv_para.sub_dv_res->bmp_subset_vol[5]);
//	
//		
//		destroy_bmp_res(dv_para.sub_dv_res->cam_play_pause[0]);
//		destroy_bmp_res(dv_para.sub_dv_res->cam_play_pause[1]);

//		__msg("DV_Uipara_Subset_UnInit end\n");

//}

void Dv_Uipara_UnInit( void )
{
	__s32 i;
		
    if(dv_para.single0_handle)
    {
        dsk_theme_close(dv_para.single0_handle);
        dv_para.single0_handle = NULL ;
    }
    if(dv_para.single1_handle)
    {
        dsk_theme_close(dv_para.single1_handle);
        dv_para.single1_handle = NULL ;
    }
    if(dv_para.single2_handle)
    {
        dsk_theme_close(dv_para.single2_handle);
        dv_para.single2_handle = NULL ;
    }
    if(dv_para.single3_handle)
    {
        dsk_theme_close(dv_para.single3_handle);
        dv_para.single3_handle = NULL ;
    }
    if(dv_para.single4_handle)
    {
        dsk_theme_close(dv_para.single4_handle);
        dv_para.single4_handle = NULL ;
    }

    if(dv_para.msg_box_bg)
    {
        dsk_theme_close(dv_para.msg_box_bg);
        dv_para.msg_box_bg = NULL ;
    }
    if(dv_para.hbar_back_handle)
    {
        dsk_theme_close(dv_para.hbar_back_handle);
        dv_para.hbar_back_handle = NULL ;
    }
	
}

dv_uipara_para_t *Dv_GetUipara( void )
{
    return &dv_para;
}


