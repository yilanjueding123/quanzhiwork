/*
************************************************************************************************************************
*                                                        MUSIC
*                                                   the Audio Player
*
*                             Copyright(C), 2006-2009, SoftWinners Microelectronic Co., Ltd.
*											       All Rights Reserved
*
* File Name   : widget_i.h
*
* Author      : Gary.Wang
*
* Version     : 1.1.0
*
* Date        : 2008.11.08
*
* Description :
*
* Others      : None at present.
*
*
* History     :
*
*  <Author>        <time>       <version>      <description>
*
* Gary.Wang      2008.11.08       1.1.0        build the file
*
************************************************************************************************************************
*/
#ifndef  __widget_i_h
#define  __widget_i_h


//#include "..\\music_i.h"

//#include "spectrum.h"

#endif     //  ifndef __widget_i_h

/* end of widget_i.h */
